from __future__ import annotations

import html
import os
import plistlib
import shlex
import subprocess
from pathlib import Path


def _systemd_quote(value: str | Path) -> str:
    # systemd accepts standard C-style quoting; shlex.quote is not parsed by
    # ExecStart. Double quotes are safe here for our fixed local paths.
    return '"' + str(value).replace('\\', '\\\\').replace('"', '\\"') + '"'


def linux_worker_units(root: Path, python_executable: str, owner: str) -> dict[str, str]:
    wrapper = root / "worker_main.py"
    monitor_service = f"""[Unit]\nDescription=M3DIA Compute Worker monitor\nAfter=network-online.target\nWants=network-online.target\n\n[Service]\nType=oneshot\nUser={owner}\nEnvironment=M3DIA_WORKER_CONFIG={root / 'State' / 'worker.json'}\nExecStart={_systemd_quote(python_executable)} {_systemd_quote(wrapper)} monitor --no-reschedule\nNice=10\n\n[Install]\nWantedBy=multi-user.target\n"""
    monitor_timer = """[Unit]\nDescription=M3DIA Compute Worker monitor timer\n\n[Timer]\nOnBootSec=5s\nOnUnitInactiveSec=1s\nAccuracySec=250ms\nUnit=m3dia-worker-monitor.service\n\n[Install]\nWantedBy=timers.target\n"""
    admin_service = f"""[Unit]\nDescription=M3DIA Compute Worker privileged executor\nAfter=network.target\n\n[Service]\nType=oneshot\nEnvironment=M3DIA_WORKER_CONFIG={root / 'State' / 'worker.json'}\nExecStart={_systemd_quote(python_executable)} {_systemd_quote(wrapper)} admin-executor\n"""
    admin_path = f"""[Unit]\nDescription=M3DIA Compute Worker privileged queue watcher\n\n[Path]\nPathExistsGlob={root / 'AdminQueue' / '*.json'}\nUnit=m3dia-worker-admin.service\n\n[Install]\nWantedBy=multi-user.target\n"""
    return {
        "m3dia-worker-monitor.service": monitor_service,
        "m3dia-worker-monitor.timer": monitor_timer,
        "m3dia-worker-admin.service": admin_service,
        "m3dia-worker-admin.path": admin_path,
    }


def _plist_bytes(obj: dict) -> str:
    return plistlib.dumps(obj, fmt=plistlib.FMT_XML, sort_keys=False).decode("utf-8")


def macos_worker_plists(root: Path, python_executable: str, owner: str) -> dict[str, str]:
    wrapper = str(root / "worker_main.py")
    cfg = str(root / "State" / "worker.json")
    monitor = {
        "Label": "com.m3dia.worker.monitor",
        "ProgramArguments": [python_executable, wrapper, "monitor", "--no-reschedule"],
        "EnvironmentVariables": {"M3DIA_WORKER_CONFIG": cfg},
        "UserName": owner,
        "RunAtLoad": True,
        "StartInterval": 1,
        "ProcessType": "Background",
        "StandardOutPath": "/dev/null",
        "StandardErrorPath": "/dev/null",
        "LowPriorityIO": True,
    }
    admin = {
        "Label": "com.m3dia.worker.admin",
        "ProgramArguments": [python_executable, wrapper, "admin-executor"],
        "EnvironmentVariables": {"M3DIA_WORKER_CONFIG": cfg},
        "QueueDirectories": {str(root / "AdminQueue"): True},
        "ProcessType": "Background",
        "StandardOutPath": "/dev/null",
        "StandardErrorPath": "/dev/null",
    }
    return {
        "com.m3dia.worker.monitor.plist": _plist_bytes(monitor),
        "com.m3dia.worker.admin.plist": _plist_bytes(admin),
    }


def install_linux_units(root: Path, python_executable: str, owner: str) -> None:
    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        raise PermissionError("Linux Worker integration requires root during installation")
    units = linux_worker_units(root, python_executable, owner)
    unit_root = Path("/etc/systemd/system")
    for name, content in units.items():
        (unit_root / name).write_text(content, encoding="utf-8")
    subprocess.run(["systemctl", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "enable", "--now", "m3dia-worker-monitor.timer", "m3dia-worker-admin.path"], check=True)


def install_macos_plists(root: Path, python_executable: str, owner: str) -> None:
    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        raise PermissionError("macOS Worker integration requires root during installation")
    plists = macos_worker_plists(root, python_executable, owner)
    target = Path("/Library/LaunchDaemons")
    for name, content in plists.items():
        path = target / name
        path.write_text(content, encoding="utf-8")
        os.chmod(path, 0o644)
        subprocess.run(["chown", "root:wheel", str(path)], check=True)
        subprocess.run(["launchctl", "bootout", "system", str(path)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["launchctl", "bootstrap", "system", str(path)], check=True)
