#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
LOG="/var/log/m3dia-compute-bootstrap.cmtrace.log"
ORIGINAL_USER=${SUDO_USER:-${USER:-$(id -un)}}

cmtrace() {
  msg=$1; typ=${2:-1}; now=$(date '+%H:%M:%S.000'); day=$(date '+%m-%d-%Y')
  printf '<![LOG[%s]LOG]!><time="%s" date="%s" component="Bootstrap" context="" type="%s" thread="%s" file="">\n' "$msg" "$now" "$day" "$typ" "$$" >> "$LOG" 2>/dev/null || true
}

if [ "$(id -u)" -ne 0 ]; then
  exec sudo M3DIA_INSTALL_USER="$ORIGINAL_USER" /bin/sh "$0"
fi
ORIGINAL_USER=${M3DIA_INSTALL_USER:-$ORIGINAL_USER}
export M3DIA_INSTALL_USER="$ORIGINAL_USER"
cmtrace "Installation macOS commencee pour l'utilisateur $ORIGINAL_USER."

PY=$(command -v python3 || true)
if [ -z "$PY" ]; then
  PKG="/tmp/m3dia-python-3.14.7-macos11.pkg"
  URL="https://www.python.org/ftp/python/3.14.7/python-3.14.7-macos11.pkg"
  cmtrace "Python 3 absent; telechargement du package officiel Python 3.14.7."
  /usr/bin/curl -fL --retry 3 --connect-timeout 15 "$URL" -o "$PKG"
  /usr/sbin/installer -pkg "$PKG" -target /
  rm -f "$PKG"
  PY=$(command -v python3 || true)
  [ -n "$PY" ] || PY="/Library/Frameworks/Python.framework/Versions/3.14/bin/python3"
fi

FRAGMENT=$($PY - <<'PY'
import urllib.request
url='https://raw.githubusercontent.com/damcuvelier/M3DIACompute/main/worker/sharedsecret.txt'
with urllib.request.urlopen(url, timeout=20) as r:
    value=r.read().decode('utf-8-sig').strip()
if not value or len(value)>64:
    raise SystemExit('fragment SharedSecret invalide')
print(value)
PY
)
export M3DIA_INSTALL_SHARED_FRAGMENT="$FRAGMENT"
cmtrace "Fragment SharedSecret recupere depuis GitHub (longueur=${#FRAGMENT}); valeur non journalisee."

$PY "$ROOT/bootstrap.py" --role worker --payload-root "$ROOT"
rc=$?
cmtrace "Installation macOS terminee avec code $rc." "$([ "$rc" -eq 0 ] && echo 1 || echo 3)"
exit "$rc"
