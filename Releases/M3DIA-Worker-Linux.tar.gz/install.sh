#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
LOG="/var/log/m3dia-compute-bootstrap.cmtrace.log"
ORIGINAL_USER=${SUDO_USER:-${USER:-$(id -un)}}

cmtrace() {
  msg=$1; typ=${2:-1}; now=$(date '+%H:%M:%S.000'); day=$(date '+%m-%d-%Y')
  printf '<![LOG[%s]LOG]!><time="%s" date="%s" component="Bootstrap" context="" type="%s" thread="%s" file="">\n' "$msg" "$now" "$day" "$typ" "$$" >> "$LOG" 2>/dev/null || true
}

if [ "$(id -u)" -ne 0 ]; then
  if command -v sudo >/dev/null 2>&1; then
    exec sudo M3DIA_INSTALL_USER="$ORIGINAL_USER" /bin/sh "$0"
  fi
  echo "M3DIA Worker: droits administrateur requis une seule fois pour l'installation." >&2
  exit 10
fi
ORIGINAL_USER=${M3DIA_INSTALL_USER:-$ORIGINAL_USER}
export M3DIA_INSTALL_USER="$ORIGINAL_USER"
cmtrace "Installation Linux commencee pour l'utilisateur $ORIGINAL_USER."

PY=$(command -v python3 || true)
if [ -z "$PY" ]; then
  cmtrace "Python 3 absent; installation via le gestionnaire de paquets." 2
  if command -v apt-get >/dev/null 2>&1; then apt-get update && apt-get install -y python3 python3-pip python3-venv
  elif command -v dnf >/dev/null 2>&1; then dnf install -y python3 python3-pip
  elif command -v yum >/dev/null 2>&1; then yum install -y python3 python3-pip
  elif command -v zypper >/dev/null 2>&1; then zypper --non-interactive install python3 python3-pip
  elif command -v pacman >/dev/null 2>&1; then pacman -Sy --noconfirm python python-pip
  elif command -v apk >/dev/null 2>&1; then apk add --no-cache python3 py3-pip
  else cmtrace "Aucun gestionnaire de paquets Python supporte." 3; exit 2
  fi
  PY=$(command -v python3)
fi

FRAGMENT=$($PY - <<'PY'
import urllib.request
url='https://raw.githubusercontent.com/damcuvelier/M3DIACompute/main/worker/sharedsecret.txt'
with urllib.request.urlopen(url, timeout=20) as r:
    value=r.read().decode('utf-8-sig').strip()
if not value or len(value)>64:
    raise SystemExit('fragment SharedSecret invalide')
print(value)
PY
)
export M3DIA_INSTALL_SHARED_FRAGMENT="$FRAGMENT"
cmtrace "Fragment SharedSecret recupere depuis GitHub (longueur=${#FRAGMENT}); valeur non journalisee."

$PY "$ROOT/bootstrap.py" --role worker --payload-root "$ROOT"
rc=$?
cmtrace "Installation Linux terminee avec code $rc." "$([ "$rc" -eq 0 ] && echo 1 || echo 3)"
exit "$rc"
