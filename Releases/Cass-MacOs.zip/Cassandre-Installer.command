#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUNDLE="$ROOT/.cassandre/M3DIA-Worker-macOS.zip"
SUMFILE="$ROOT/.cassandre/M3DIA-Worker-macOS.zip.sha256"
FRAGMENT_FILE="$ROOT/.cassandre/worker-shared-fragment.txt"
LOG="/tmp/Cassandre-Worker-Installer.cmtrace.log"
ORIGINAL_USER=${USER:-$(id -un)}
cmtrace(){ msg=$1; typ=${2:-1}; now=$(date '+%H:%M:%S.000'); day=$(date '+%m-%d-%Y'); printf '<![LOG[%s]LOG]!><time="%s" date="%s" component="CassandreMacInstaller" context="" type="%s" thread="%s" file="">\n' "$msg" "$now" "$day" "$typ" "$$" >> "$LOG" 2>/dev/null || true; }
fail(){ cmtrace "$1" 3; printf '\nERREUR : %s\nJournal : %s\n' "$1" "$LOG"; printf '\nAppuyez sur Entree pour fermer.\n'; read dummy; exit 1; }
clear
printf '\nCassandre Worker - Installation macOS\n\n'
cmtrace "Lanceur macOS autonome demarre."
[ -f "$BUNDLE" ] || fail "Le paquet integre du WORKER est introuvable."
[ -f "$SUMFILE" ] || fail "Le fichier de controle SHA-256 est introuvable."
[ -f "$FRAGMENT_FILE" ] || fail "Le fragment d installation integre est introuvable."
FRAGMENT=$(tr -d '\r\n' < "$FRAGMENT_FILE")
[ -n "$FRAGMENT" ] && [ "${#FRAGMENT}" -le 64 ] || fail "Le fragment d installation integre est invalide."
expected=$(awk 'NF {print toupper($1); exit}' "$SUMFILE")

actual=$(/usr/bin/shasum -a 256 "$BUNDLE" | awk '{print toupper($1)}')
[ -n "$expected" ] || fail "Empreinte SHA-256 attendue absente."
[ "$actual" = "$expected" ] || fail "Le paquet du WORKER est endommage ou incomplet."
cmtrace "Paquet integre verifie SHA-256."
TMP="/tmp/cassandre-worker-install-$$"
mkdir -p "$TMP"
cp "$BUNDLE" "$TMP/M3DIA-Worker-macOS.zip"
cp "$FRAGMENT_FILE" "$TMP/worker-shared-fragment.txt"
/bin/chmod 600 "$TMP/worker-shared-fragment.txt"
cat > "$TMP/install-root.sh" <<EOF
#!/bin/sh
set -eu
ZIP="$TMP/M3DIA-Worker-macOS.zip"
PAYLOAD="$TMP/payload"
FRAGMENT=\$(tr -d '\\r\\n' < "$TMP/worker-shared-fragment.txt")
[ -n "\$FRAGMENT" ] && [ "\${#FRAGMENT}" -le 64 ] || exit 22
mkdir -p "\$PAYLOAD"
/usr/bin/ditto -x -k "\$ZIP" "\$PAYLOAD"
launcher=\$(find "\$PAYLOAD" -type f -name 'install.command' -print -quit)
[ -n "\$launcher" ] || exit 21
/bin/chmod +x "\$launcher"
/usr/bin/xattr -dr com.apple.quarantine "\$PAYLOAD" 2>/dev/null || true
/usr/bin/env M3DIA_INSTALL_USER="$ORIGINAL_USER" M3DIA_INSTALL_SHARED_FRAGMENT="\$FRAGMENT" /bin/sh "\$launcher"
EOF
/bin/chmod 700 "$TMP/install-root.sh"
ESCAPED=$(printf '%s' "$TMP/install-root.sh" | /usr/bin/sed "s/'/'\\\\''/g")
printf 'Une autorisation administrateur macOS va etre demandee une seule fois.\n\n'
if /usr/bin/osascript -e "do shell script \"/bin/sh '$ESCAPED'\" with administrator privileges"; then
  rc=0;cmtrace "Installation macOS terminee avec succes.";printf '\nCassandre Worker est installe.\n'
else
  rc=$?;cmtrace "Installation macOS annulee ou en echec; code=$rc." 3;printf '\nInstallation annulee ou en echec.\nJournal : %s\n' "$LOG"
fi
/bin/rm -rf "$TMP"
printf '\nAppuyez sur Entree pour fermer.\n';read dummy
exit "$rc"
