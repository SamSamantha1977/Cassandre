from __future__ import annotations

import configparser
import hashlib
import hmac
from pathlib import Path

PROTOCOL_LABEL = "M3DIA-WORKER-REGISTER"


def build_install_sharedsecret(fragment: str, suffix: str) -> str:
    """Rebuild the installation SharedSecret in memory only.

    The public GitHub fragment and the package-local suffix are deliberately
    separate.  The returned value must never be persisted by callers.
    """
    left = str(fragment or "").strip()
    right = str(suffix or "").strip()
    if not left or not right:
        raise ValueError("SharedSecret fragments are incomplete")
    return "wkr-" + left + right


def read_secret_suffix(config_path: str | Path) -> str:
    path = Path(config_path)
    parser = configparser.ConfigParser(interpolation=None)
    with path.open("r", encoding="utf-8") as fh:
        parser.read_file(fh)
    suffix = parser.get("Worker", "SharedSecret", fallback="").strip()
    if not suffix:
        raise ValueError(f"SharedSecret is missing from {path}")
    return suffix


def registration_message(worker_id: str, challenge_id: str, nonce: str) -> bytes:
    parts = [PROTOCOL_LABEL, str(worker_id).strip(), str(challenge_id).strip(), str(nonce).strip()]
    if any(not p for p in parts):
        raise ValueError("registration challenge fields must not be empty")
    return "\n".join(parts).encode("utf-8")


def registration_proof(secret: str, worker_id: str, challenge_id: str, nonce: str) -> str:
    key = str(secret).encode("utf-8")
    return hmac.new(key, registration_message(worker_id, challenge_id, nonce), hashlib.sha256).hexdigest().upper()
