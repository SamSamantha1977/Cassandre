from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .common import parse_iso, utcnow


DAYS = ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")
DEFAULT_TIMEZONE = "Europe/Paris"
PLANNING_CONFIG_PREFIX = "availability/user-planning.json."


def planning_logical_config_name(hostname: str) -> str:
    return PLANNING_CONFIG_PREFIX + _safe_config_token(hostname)


def load_worker_planning(config_root: str | Path, hostname: str) -> dict:
    path = Path(config_root) / Path(planning_logical_config_name(hostname))
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default_planning()
    return data if isinstance(data, dict) else default_planning()


def planning_allows_compute(planning: dict, moment=None) -> tuple[bool, str]:
    if not isinstance(planning, dict):
        return True, "default"
    mode = str(planning.get("mode", "none") or "none").strip().lower()
    if mode == "none":
        return True, "default"
    if mode not in {"allow", "deny"}:
        return True, "default-invalid-mode"

    now_utc = moment or utcnow()
    timezone = str(planning.get("timezone", DEFAULT_TIMEZONE) or DEFAULT_TIMEZONE)
    local_now = _to_local_time(now_utc, timezone)

    exception = _matching_exception(planning.get("exceptions") or [], now_utc)
    if exception is not None:
        return bool(exception.get("available", False)), "exception"

    day = DAYS[local_now.weekday()]
    ranges = planning.get("weekly") or {}
    active = any(_time_in_range(local_now.strftime("%H:%M"), item) for item in ranges.get(day, []) if isinstance(item, dict))
    if mode == "allow":
        return active, "weekly-allow" if active else "weekly-allow-outside"
    return not active, "weekly-deny-blocked" if active else "weekly-deny-outside"


def default_planning() -> dict:
    return {
        "version": 1,
        "timezone": DEFAULT_TIMEZONE,
        "mode": "none",
        "weekly": {day: [] for day in DAYS},
        "exceptions": [],
    }


def _matching_exception(exceptions: list[dict], now_utc) -> dict | None:
    for item in exceptions:
        if not isinstance(item, dict):
            continue
        start = parse_iso(str(item.get("start", "") or ""))
        end = parse_iso(str(item.get("end", "") or ""))
        if start and end and start <= now_utc <= end:
            return item
    return None


def _to_local_time(now_utc, timezone_name: str):
    try:
        return now_utc.astimezone(ZoneInfo(timezone_name))
    except ZoneInfoNotFoundError:
        if timezone_name == DEFAULT_TIMEZONE:
            return now_utc.astimezone(_paris_tzinfo(now_utc))
        return now_utc


def _paris_tzinfo(now_utc):
    year = now_utc.year
    dst_start = _last_sunday_utc(year, 3, 1)
    dst_end = _last_sunday_utc(year, 10, 1)
    offset = 2 if dst_start <= now_utc < dst_end else 1
    return timezone(timedelta(hours=offset))


def _last_sunday_utc(year: int, month: int, hour: int):
    day = datetime(year, month + 1, 1, hour, tzinfo=timezone.utc) - timedelta(days=1) if month < 12 else datetime(year, 12, 31, hour, tzinfo=timezone.utc)
    while day.weekday() != 6:
        day -= timedelta(days=1)
    return day


def _time_in_range(hhmm: str, item: dict) -> bool:
    start = str(item.get("start", "") or "")
    end = str(item.get("end", "") or "")
    return bool(start <= hhmm < end)


def _safe_config_token(value: str) -> str:
    token = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip())
    token = token.strip("._-")
    if not token:
        return "UNKNOWN"
    return token[:80]
