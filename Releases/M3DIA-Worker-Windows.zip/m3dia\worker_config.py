from __future__ import annotations

import base64
import contextlib
import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

from .common import ensure_dir, sha256_bytes


STAMP_FORMAT = "%y%m%d-%H%M%S"
WORKER_CONFIG_REQUIRED = {
    "rendezvous_url", "heartbeat_interval_seconds", "work_poll_interval_seconds",
    "idle_threshold_seconds", "retry_interval_hours", "health_timeout_seconds",
    "connection_timeout_seconds", "resource_guard_interval_seconds",
    "checkpoint_interval_seconds", "result_chunk_bytes", "cpu_reserve_percent",
    "ram_reserve_percent", "ram_reserve_minimum_mb", "gpu_reserve_percent",
    "vram_reserve_percent", "vram_reserve_minimum_mb", "disk_reserve_minimum_mb",
    "allow_compute_on_battery", "minimum_battery_percent"
}


def latest_local_file_date(root: str | Path) -> str:
    config_root = Path(root)
    latest = 0.0
    if config_root.exists():
        for path in config_root.rglob("*"):
            if path.is_file() and not path.name.endswith(".tmp"):
                with contextlib.suppress(OSError):
                    latest = max(latest, path.stat().st_mtime)
    return datetime.fromtimestamp(latest).strftime(STAMP_FORMAT) if latest else ""


def apply_config_response(config_root: str | Path, response: dict) -> tuple[list[str], list[str], str]:
    update = response.get("ConfigUpdate") if isinstance(response, dict) else None
    if not isinstance(update, dict):
        return [], [], str(response.get("ConfigGeneration", "")) if isinstance(response, dict) else ""
    generation = str(update.get("Generation", ""))
    applied: list[str] = []
    failed: list[str] = []
    root = ensure_dir(config_root)
    for item in update.get("Files") or []:
        name = str(item.get("Name", "")).replace("\\", "/").lstrip("/")
        try:
            if not name or any(part in ("", ".", "..") for part in name.split("/")):
                raise ValueError("unsafe configuration path")
            data = base64.b64decode(str(item.get("ContentBase64", "")), validate=True)
            expected = str(item.get("Sha256", "")).upper()
            if not expected or sha256_bytes(data) != expected:
                raise ValueError("SHA-256 mismatch")
            if name == "worker-config.json":
                document = json.loads(data.decode("utf-8-sig"))
                if not isinstance(document, dict) or not WORKER_CONFIG_REQUIRED.issubset(document):
                    raise ValueError("incomplete worker configuration")
            target = root / Path(name)
            ensure_dir(target.parent)
            fd, temporary = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=str(target.parent))
            try:
                with os.fdopen(fd, "wb") as stream:
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary, target)
                os.utime(target, None)
            finally:
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(temporary)
            applied.append(name)
        except Exception:
            failed.append(name or "<invalid>")
    return applied, failed, generation
