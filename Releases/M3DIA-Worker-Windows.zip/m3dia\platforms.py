from __future__ import annotations
import contextlib, ctypes, json, math, os, platform, re, shutil, signal, subprocess, sys, time
from ctypes import wintypes
from pathlib import Path
from typing import Any

IS_WINDOWS=os.name=="nt"
IS_MACOS=sys.platform=="darwin"
IS_LINUX=(not IS_WINDOWS and not IS_MACOS)

# Windows background-process policy:
# M3DIA background work must NEVER create a console window, even for a few
# milliseconds.  CREATE_NO_WINDOW prevents allocation of a console for child
# console applications; STARTUPINFO/SW_HIDE is an additional belt-and-braces
# safeguard for programs that honour ShowWindow.
def hidden_process_kwargs(*, below_normal: bool = False) -> dict:
    if not IS_WINDOWS:
        return {}
    flags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
    if below_normal:
        flags |= int(getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0x00004000))
    out = {"creationflags": flags}
    if hasattr(subprocess, "STARTUPINFO"):
        si = subprocess.STARTUPINFO()
        si.dwFlags |= int(getattr(subprocess, "STARTF_USESHOWWINDOW", 0x00000001))
        si.wShowWindow = int(getattr(subprocess, "SW_HIDE", 0))
        out["startupinfo"] = si
    return out

def _hidden_run(args, **kwargs):
    if IS_WINDOWS:
        for k, v in hidden_process_kwargs().items():
            kwargs.setdefault(k, v)
    return subprocess.run(args, **kwargs)

def _hidden_check_output(args, **kwargs):
    if IS_WINDOWS:
        for k, v in hidden_process_kwargs().items():
            kwargs.setdefault(k, v)
    return subprocess.check_output(args, **kwargs)

def _parse_macos_hid_idle_seconds(text: str) -> int:
    match=re.search(r'"HIDIdleTime"\s*=\s*(\d+)',str(text or ""))
    return int(int(match.group(1))//1_000_000_000) if match else 0

def _parse_macos_pmset_batt(text: str) -> dict:
    raw=str(text or "")
    on_ac="AC Power" in raw
    match=re.search(r'(\d{1,3})%',raw)
    percent=int(match.group(1)) if match else -1
    return {"on_ac":on_ac,"battery_percent":percent}

def _parse_macos_vm_stat(text: str, total_bytes: int) -> dict:
    raw=str(text or "")
    page_match=re.search(r'page size of (\d+) bytes',raw)
    page_size=int(page_match.group(1)) if page_match else 4096
    values={}
    for line in raw.splitlines():
        match=re.match(r'([^:]+):\s*(\d+)\.?',line.strip())
        if match:values[match.group(1).strip()]=int(match.group(2))
    available_pages=sum(values.get(key,0) for key in ("Pages free","Pages inactive","Pages speculative"))
    total_mb=max(0,int(total_bytes)//1048576);available_mb=max(0,int(available_pages*page_size)//1048576)
    return {"total_mb":total_mb,"available_mb":min(total_mb,available_mb),"load_percent":0 if not total_mb else int(round(100*(1-min(total_mb,available_mb)/total_mb)))}

def _macos_console_user() -> str:
    try:
        user=subprocess.check_output(["stat","-f","%Su","/dev/console"],text=True,timeout=2).strip()
        return "" if user in ("", "root", "loginwindow") else user
    except Exception:return ""

def idle_seconds() -> int:
    if IS_WINDOWS:
        class LASTINPUTINFO(ctypes.Structure): _fields_=[("cbSize",wintypes.UINT),("dwTime",wintypes.DWORD)]
        li=LASTINPUTINFO(); li.cbSize=ctypes.sizeof(li)
        if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(li)): return 0
        tick=ctypes.windll.kernel32.GetTickCount()
        return int(((tick-li.dwTime)&0xFFFFFFFF)/1000)
    if IS_MACOS:
        try:
            out=subprocess.check_output(["ioreg","-c","IOHIDSystem","-r","-d","1"],text=True,stderr=subprocess.DEVNULL,timeout=2)
            return _parse_macos_hid_idle_seconds(out)
        except Exception:return 0 if _macos_console_user() else 2**31-1
    try:
        sid=os.getenv("XDG_SESSION_ID")
        if sid:
            out=subprocess.check_output(["loginctl","show-session",sid,"-p","IdleHint","-p","IdleSinceHintMonotonic","--value"],text=True,timeout=2).splitlines()
            if out and out[0].strip().lower()=="yes":
                if len(out)>1 and out[1].strip().isdigit():
                    since=int(out[1].strip())/1_000_000; return max(0,int(time.monotonic()-since))
                return 3600
            return 0
    except Exception:pass
    try:return max(0,int(int(subprocess.check_output(["xprintidle"],text=True,timeout=2).strip())/1000))
    except Exception:return 2**31-1 if not os.getenv("DISPLAY") and not os.getenv("WAYLAND_DISPLAY") else 0

def interactive_user_present() -> bool:
    """Return True when Windows has at least one interactive user session.

    The Controller HTTPS service runs as SYSTEM.  GetLastInputInfo is session
    scoped, so the SYSTEM service cannot use it to decide whether the owner is
    active.  ActivityProbe runs inside the owner's interactive session.  If
    that probe becomes stale because the user logged off, the controller must
    not remain LOCAL_PRIORITY forever.  WTS is used here only to distinguish
    "no interactive user" from "probe unexpectedly stale".
    """
    if IS_MACOS:
        return bool(_macos_console_user())
    if not IS_WINDOWS:
        return bool(os.getenv("DISPLAY") or os.getenv("WAYLAND_DISPLAY") or os.getenv("XDG_SESSION_ID"))
    try:
        WTS_CURRENT_SERVER_HANDLE = wintypes.HANDLE(0)
        WTSActive = 0
        WTSConnected = 1
        WTSUserName = 5

        class WTS_SESSION_INFO(ctypes.Structure):
            _fields_ = [
                ("SessionId", wintypes.DWORD),
                ("pWinStationName", wintypes.LPWSTR),
                ("State", ctypes.c_int),
            ]

        pp = ctypes.POINTER(WTS_SESSION_INFO)()
        count = wintypes.DWORD(0)
        wts = ctypes.windll.wtsapi32
        if not wts.WTSEnumerateSessionsW(WTS_CURRENT_SERVER_HANDLE, 0, 1, ctypes.byref(pp), ctypes.byref(count)):
            return True  # conservative on API failure
        try:
            for i in range(int(count.value)):
                info = pp[i]
                if info.State not in (WTSActive, WTSConnected):
                    continue
                buf = wintypes.LPWSTR()
                size = wintypes.DWORD(0)
                if wts.WTSQuerySessionInformationW(
                    WTS_CURRENT_SERVER_HANDLE,
                    info.SessionId,
                    WTSUserName,
                    ctypes.byref(buf),
                    ctypes.byref(size),
                ):
                    try:
                        if buf.value and buf.value.strip():
                            return True
                    finally:
                        wts.WTSFreeMemory(buf)
            return False
        finally:
            wts.WTSFreeMemory(pp)
    except Exception:
        return True  # conservative: never launch local compute on uncertainty

def power_state() -> dict:
    if IS_WINDOWS:
        class SYSTEM_POWER_STATUS(ctypes.Structure):
            _fields_=[("ACLineStatus",ctypes.c_ubyte),("BatteryFlag",ctypes.c_ubyte),("BatteryLifePercent",ctypes.c_ubyte),("SystemStatusFlag",ctypes.c_ubyte),("BatteryLifeTime",wintypes.DWORD),("BatteryFullLifeTime",wintypes.DWORD)]
        s=SYSTEM_POWER_STATUS(); ok=ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(s))
        return {"on_ac": bool(ok and s.ACLineStatus==1), "battery_percent": -1 if not ok or s.BatteryLifePercent==255 else int(s.BatteryLifePercent)}
    if IS_MACOS:
        try:return _parse_macos_pmset_batt(subprocess.check_output(["pmset","-g","batt"],text=True,stderr=subprocess.DEVNULL,timeout=2))
        except Exception:return {"on_ac":True,"battery_percent":-1}
    for base in Path("/sys/class/power_supply").glob("*"):
        try:
            typ=(base/"type").read_text().strip().lower()
            if typ in ("mains","ac"):
                online=(base/"online").read_text().strip()=="1"
                return {"on_ac":online,"battery_percent":_battery_percent_linux()}
        except Exception: pass
    return {"on_ac":True,"battery_percent":_battery_percent_linux()}

def _battery_percent_linux()->int:
    vals=[]
    for p in Path("/sys/class/power_supply").glob("BAT*"):
        try: vals.append(int((p/"capacity").read_text().strip()))
        except Exception: pass
    return int(sum(vals)/len(vals)) if vals else -1

def memory_snapshot() -> dict:
    if IS_WINDOWS:
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_=[("dwLength",wintypes.DWORD),("dwMemoryLoad",wintypes.DWORD),("ullTotalPhys",ctypes.c_ulonglong),("ullAvailPhys",ctypes.c_ulonglong),("ullTotalPageFile",ctypes.c_ulonglong),("ullAvailPageFile",ctypes.c_ulonglong),("ullTotalVirtual",ctypes.c_ulonglong),("ullAvailVirtual",ctypes.c_ulonglong),("ullAvailExtendedVirtual",ctypes.c_ulonglong)]
        m=MEMORYSTATUSEX(); m.dwLength=ctypes.sizeof(m)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)): raise OSError("GlobalMemoryStatusEx failed")
        return {"total_mb":int(m.ullTotalPhys//1048576),"available_mb":int(m.ullAvailPhys//1048576),"load_percent":int(m.dwMemoryLoad)}
    if IS_MACOS:
        total=int(subprocess.check_output(["sysctl","-n","hw.memsize"],text=True,timeout=2).strip())
        vm=subprocess.check_output(["vm_stat"],text=True,timeout=2)
        return _parse_macos_vm_stat(vm,total)
    data={}
    for line in Path("/proc/meminfo").read_text().splitlines():
        k,v=line.split(":",1); data[k]=int(v.strip().split()[0])
    total=data.get("MemTotal",0)//1024; avail=data.get("MemAvailable",data.get("MemFree",0))//1024
    return {"total_mb":total,"available_mb":avail,"load_percent":0 if not total else int(round(100*(1-avail/total)))}

def _cpu_times_windows():
    idle=wintypes.FILETIME(); kernel=wintypes.FILETIME(); user=wintypes.FILETIME()
    if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)): raise OSError("GetSystemTimes failed")
    cv=lambda x:(x.dwHighDateTime<<32)|x.dwLowDateTime
    return cv(idle),cv(kernel),cv(user)

def _cpu_times_linux():
    vals=list(map(int,Path("/proc/stat").read_text().splitlines()[0].split()[1:]))
    idle=vals[3]+(vals[4] if len(vals)>4 else 0); total=sum(vals); return idle,total

def cpu_load_percent(sample_seconds: float=.5)->float:
    if IS_WINDOWS:
        a=_cpu_times_windows(); time.sleep(sample_seconds); b=_cpu_times_windows(); idle=b[0]-a[0]; total=(b[1]-a[1])+(b[2]-a[2]); return round(max(0,min(100,100*(1-idle/total))) if total else 0,1)
    if IS_MACOS:
        try:
            out=subprocess.check_output(["ps","-A","-o","%cpu="],text=True,stderr=subprocess.DEVNULL,timeout=max(2,float(sample_seconds)+1))
            total=sum(float(x.strip()) for x in out.splitlines() if x.strip())
            return round(max(0.0,min(100.0,total/max(1,os.cpu_count() or 1))),1)
        except Exception:return 0.0
    a=_cpu_times_linux(); time.sleep(sample_seconds); b=_cpu_times_linux(); idle=b[0]-a[0]; total=b[1]-a[1]; return round(max(0,min(100,100*(1-idle/total))) if total else 0,1)

def gpu_inventory(cfg:dict) -> list[dict]:
    smi=shutil.which("nvidia-smi") or shutil.which("nvidia-smi.exe")
    out=[]
    if smi:
        try:
            cmd=[smi,"--query-gpu=index,name,memory.total,memory.free,utilization.gpu,driver_version","--format=csv,noheader,nounits"]
            rows=_hidden_check_output(cmd,text=True,stderr=subprocess.DEVNULL,timeout=5).splitlines()
            for row in rows:
                p=[x.strip() for x in row.split(",")]
                if len(p)<6: continue
                total=int(float(p[2])); free=int(float(p[3])); util=int(float(p[4])); vr=max(int(cfg.get("vram_reserve_minimum_mb",1024)),math.ceil(total*cfg.get("vram_reserve_percent",10)/100)); safe_v=max(0,free-vr); safe_g=max(0,100-util-int(cfg.get("gpu_reserve_percent",15)))
                out.append({"index":int(p[0]),"name":p[1],"vendor":"NVIDIA","driver_version":p[5],"compute_backend":"CUDA","vram_total_mb":total,"vram_free_now_mb":free,"vram_reserve_mb":vr,"safe_available_vram_mb":safe_v,"current_utilization_percent":util,"safe_available_gpu_percent":safe_g,"safe_for_compute":safe_g>=10 and safe_v>=256,"measurement":"nvidia-smi-live"})
        except Exception: pass
    return out

def resources(cfg:dict, cpu_sample_seconds:float=.4)->dict:
    mem=memory_snapshot(); load=cpu_load_percent(cpu_sample_seconds); logical=os.cpu_count() or 1
    cr=int(cfg.get("cpu_reserve_percent",20)); safe_cpu=max(0,int(math.floor(100-load-cr))); safe_threads=max(0,int(math.floor(logical*safe_cpu/100)))
    if safe_threads<1 and safe_cpu>=10: safe_threads=1
    rr=max(int(cfg.get("ram_reserve_minimum_mb",4096)),math.ceil(mem["total_mb"]*int(cfg.get("ram_reserve_percent",20))/100)); safe_ram=max(0,mem["available_mb"]-rr)
    root=Path(cfg.get("resource_disk_path") or cfg.get("install_root") or Path.home()); du=shutil.disk_usage(root if root.exists() else Path.home()); disk_free=int(du.free//1048576); dr=int(cfg.get("disk_reserve_minimum_mb",8192)); safe_disk=max(0,disk_free-dr)
    gpus=gpu_inventory(cfg); best_gpu=max([g["safe_available_gpu_percent"] for g in gpus]+[0]); best_vram=max([g["safe_available_vram_mb"] for g in gpus]+[0]); power=power_state(); battery_safe=power["on_ac"] or bool(cfg.get("allow_compute_on_battery",False));
    if not power["on_ac"] and battery_safe and 0<=power["battery_percent"]<int(cfg.get("minimum_battery_percent",50)): battery_safe=False
    return {"cpu_logical_threads":logical,"cpu_current_load_percent":load,"safe_available_cpu_percent":safe_cpu,"safe_available_cpu_threads":safe_threads,"ram_total_mb":mem["total_mb"],"ram_available_now_mb":mem["available_mb"],"ram_reserve_mb":rr,"safe_available_ram_mb":safe_ram,"disk_free_now_mb":disk_free,"disk_reserve_mb":dr,"safe_available_disk_mb":safe_disk,"gpus":gpus,"gpu_compute_available":any(g["safe_for_compute"] for g in gpus),"safe_available_gpu_percent":best_gpu,"safe_available_vram_mb":best_vram,"gpu_backends":sorted(set(g["compute_backend"] for g in gpus if g.get("safe_for_compute"))),"on_ac_power":power["on_ac"],"battery_percent":power["battery_percent"],"power_policy_safe":battery_safe}

def capabilities(res:dict)->list[str]:
    c=["NETWORK"]
    if res.get("safe_available_cpu_threads",0)>0: c.append("CPU")
    if res.get("safe_available_ram_mb",0)>0: c.append("RAM")
    if res.get("safe_available_disk_mb",0)>0: c.append("STORAGE")
    for g in res.get("gpus",[]):
        if g.get("safe_for_compute"):
            c += ["GPU",f"GPU-{g['vendor'].upper()}",g["compute_backend"].upper()]
    return sorted(set(c))

def is_portable()->bool:
    if IS_WINDOWS:
        return power_state().get("battery_percent",-1)>=0
    if IS_MACOS:
        try:return "InternalBattery" in subprocess.check_output(["pmset","-g","batt"],text=True,stderr=subprocess.DEVNULL,timeout=2)
        except Exception:return False
    return any(Path("/sys/class/power_supply").glob("BAT*"))

class KeepAwake:
    def __init__(self): self.proc=None
    def __enter__(self):
        if IS_WINDOWS:
            # ES_CONTINUOUS | ES_SYSTEM_REQUIRED: le calcul continue, sans garder l'ecran allume.
            try: ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
            except Exception: pass
        elif IS_MACOS and shutil.which("caffeinate"):
            self.proc=subprocess.Popen(["caffeinate","-i"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        elif shutil.which("systemd-inhibit"):
            self.proc=subprocess.Popen(["systemd-inhibit","--what=sleep","--who=M3DIACompute","--why=Compute job","--mode=block","sleep","infinity"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return self
    def __exit__(self,*exc):
        if IS_WINDOWS:
            with contextlib.suppress(Exception): ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        if self.proc:
            with contextlib.suppress(Exception): self.proc.terminate()

def below_normal_kwargs()->dict:
    if IS_WINDOWS: return hidden_process_kwargs(below_normal=True)
    return {"preexec_fn":lambda: os.nice(10)}

def terminate_tree(pid:int)->None:
    if pid<=0:return
    if IS_WINDOWS:
        _hidden_run(["taskkill","/PID",str(pid),"/T","/F"],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    else:
        with contextlib.suppress(ProcessLookupError): os.killpg(os.getpgid(pid),signal.SIGTERM)
        time.sleep(.2)
        with contextlib.suppress(ProcessLookupError): os.killpg(os.getpgid(pid),signal.SIGKILL)

def process_alive(pid:int)->bool:
    if pid<=0:return False
    try:
        if IS_WINDOWS:
            r=_hidden_run(["tasklist","/FI",f"PID eq {pid}","/NH"],stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=2); return str(pid) in r.stdout
        os.kill(pid,0); return True
    except Exception:return False
