from __future__ import annotations
import base64, contextlib, hashlib, http.client, json, os, secrets, socket, ssl, tempfile, time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

VERSION = "5.1.0"
INSTALL_SHARED_SECRET_DEFAULT = ""

def utcnow() -> datetime:
    return datetime.now(timezone.utc)

def iso_now() -> str:
    return utcnow().isoformat()

def parse_iso(value: str | None) -> Optional[datetime]:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None

def ensure_dir(path: str | Path) -> Path:
    p = Path(path); p.mkdir(parents=True, exist_ok=True); return p

def atomic_json_write(path: str | Path, obj: Any) -> None:
    p = Path(path); ensure_dir(p.parent)
    fd, tmp = tempfile.mkstemp(prefix=p.name + ".", dir=str(p.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n"); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, p)
    finally:
        with contextlib.suppress(FileNotFoundError): os.unlink(tmp)

def json_read(path: str | Path, default: Any = None) -> Any:
    try:
        with open(path, "r", encoding="utf-8-sig") as f: return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError): return default

def merge_dict(base: dict, patch: dict) -> dict:
    out = dict(base)
    for k, v in (patch or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict): out[k] = merge_dict(out[k], v)
        else: out[k] = v
    return out

def cmtrace(log_file: str | Path, message: str, component: str="M3DIA", typ: int=1) -> None:
    p = Path(log_file); ensure_dir(p.parent)
    now = datetime.now()
    safe = str(message).replace("]]>", "] ]>")
    line = f'<![LOG[{safe}]LOG]!><time="{now:%H:%M:%S}.{now.microsecond//1000:03d}" date="{now:%m-%d-%Y}" component="{component}" context="" type="{typ}" thread="{os.getpid()}" file="">\n'
    with open(p, "a", encoding="utf-8") as f: f.write(line)

def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""): h.update(chunk)
    return h.hexdigest().upper()

def sha256_bytes(data: bytes) -> str: return hashlib.sha256(data).hexdigest().upper()
def new_secret(nbytes: int=32) -> str: return base64.urlsafe_b64encode(secrets.token_bytes(nbytes)).decode().rstrip("=")

def safe_relative_path(value: str) -> str:
    v = value.replace("\\", "/").lstrip("/")
    parts = [x for x in v.split("/") if x not in ("", ".")]
    if not parts or any(x == ".." for x in parts): raise ValueError(f"unsafe relative path: {value!r}")
    return "/".join(parts)

@dataclass
class HttpResult:
    status: int
    data: Any
    headers: dict[str, str]

class ControllerUnreachable(RuntimeError): pass
class TlsPinError(ControllerUnreachable): pass


def _conn(url: str, timeout: float, pin_sha256: str=""):
    from urllib.parse import urlsplit
    u = urlsplit(url)
    if u.scheme not in ("http", "https"): raise ValueError("URL scheme must be http or https")
    host = u.hostname
    if not host: raise ValueError("URL host missing")
    port = u.port or (443 if u.scheme == "https" else 80)
    if u.scheme == "https":
        context = ssl.create_default_context() if not pin_sha256 else ssl._create_unverified_context()
        c = http.client.HTTPSConnection(host, port, timeout=timeout, context=context)
    else:
        c = http.client.HTTPConnection(host, port, timeout=timeout)
    return u, c

def http_json(method: str, base_url: str, path: str, body: Any=None, timeout: float=10.0, pin_sha256: str="") -> HttpResult:
    u, c = _conn(base_url, timeout, pin_sha256)
    prefix = u.path.rstrip("/")
    target = prefix + (path if path.startswith("/") else "/"+path)
    payload = None if body is None else json.dumps(body, separators=(",", ":"), ensure_ascii=False).encode()
    headers = {"User-Agent": f"M3DIACompute/{VERSION}", "Accept":"application/json"}
    if payload is not None: headers["Content-Type"]="application/json"
    try:
        # Verify a pinned TLS certificate on the connected socket BEFORE the
        # HTTP request. http.client may close/detach c.sock after a response
        # carrying Connection: close, which made post-response pin checking
        # unreliable.
        if pin_sha256 and isinstance(c, http.client.HTTPSConnection):
            c.connect()
            cert = c.sock.getpeercert(binary_form=True) if c.sock else None
            expected = pin_sha256.replace(":", "").upper()
            actual = hashlib.sha256(cert).hexdigest().upper() if cert else ""
            if not cert or actual != expected:
                raise TlsPinError("TLS certificate fingerprint mismatch")
        c.request(method.upper(), target, body=payload, headers=headers)
        r = c.getresponse()
        raw = r.read()
        try: data = json.loads(raw.decode("utf-8")) if raw else None
        except Exception: data = raw.decode("utf-8", errors="replace")
        return HttpResult(r.status, data, {k.lower():v for k,v in r.getheaders()})
    except (OSError, ssl.SSLError, http.client.HTTPException, socket.error) as e:
        raise ControllerUnreachable(str(e)) from e
    finally:
        with contextlib.suppress(Exception): c.close()

def health_check(base_url: str, timeout: float=3.0, pin_sha256: str="") -> tuple[bool, Any]:
    try:
        r=http_json("GET", base_url, "/api/health", timeout=timeout, pin_sha256=pin_sha256)
        return True, r.data
    except ControllerUnreachable:
        return False, None

def get_rendezvous(url: str, timeout: float=5.0) -> Optional[dict]:
    if not url: return None
    from urllib.parse import urlsplit
    u=urlsplit(url)
    base=f"{u.scheme}://{u.netloc}"
    path=u.path or "/"
    if u.query: path += "?" + u.query
    try:
        r=http_json("GET", base, path, timeout=timeout)
    except ControllerUnreachable:
        return None
    if r.status in (204,404) or not r.data: return None
    return r.data if isinstance(r.data, dict) else None
