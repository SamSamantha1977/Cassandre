from __future__ import annotations
import argparse, base64, contextlib, json, os, shutil, socket, subprocess, sys, time, uuid
from datetime import timedelta
from pathlib import Path
from typing import Any
from .common import *
from .config import default_worker, worker_store
from .platforms import capabilities, idle_seconds, resources, KeepAwake, below_normal_kwargs, terminate_tree, process_alive, hidden_process_kwargs
from .planning import load_worker_planning, planning_allows_compute
from .scheduler import defer_task, run_task
from .worker_config import apply_config_response, latest_local_file_date
from .enrollment import build_install_sharedsecret, read_secret_suffix, registration_proof

TASK_MONITOR="M3DIACompute Worker Monitor"
TASK_WAKE="M3DIACompute Worker WakePoll"
TASK_RETRY="M3DIACompute Worker Retry"
TASK_JOB="M3DIACompute Worker JobRunner"
TASK_GUARD="M3DIACompute Worker JobGuard"
TASK_ADMIN="M3DIACompute Worker AdminExecutor"

REMOTE_PROTECTED={"version","name","worker_id","controller_url","previous_controller_url","pending_controller_url","pinned_tls_sha256","previous_pinned_tls_sha256","pending_pinned_tls_sha256","install_shared_secret","install_shared_fragment","install_secret_suffix_file","shared_secret","previous_shared_secret","registered","install_root","controller_offline","next_retry_at","last_heartbeat_at","next_work_poll_at","last_successful_contact","last_applied_rendezvous_generation","current_job_id","current_job_state","applied_action_ids","is_portable","controller_state","last_job_id","last_job_status"}
REQUIRED_OPERATIONAL={"rendezvous_url","heartbeat_interval_seconds","work_poll_interval_seconds","idle_threshold_seconds","retry_interval_hours","health_timeout_seconds","connection_timeout_seconds","resource_guard_interval_seconds","checkpoint_interval_seconds","result_chunk_bytes","cpu_reserve_percent","ram_reserve_percent","ram_reserve_minimum_mb","gpu_reserve_percent","vram_reserve_percent","vram_reserve_minimum_mb","disk_reserve_minimum_mb","allow_compute_on_battery","minimum_battery_percent"}

class Worker:
    def __init__(self, config_path: str|Path|None=None):
        self.store=worker_store(config_path, default_worker())
        bootstrap=self.store.load(); self.root=Path(bootstrap["install_root"])
        self.log=self.root/"Logs"/"worker.cmtrace.log"
        for d in ("Inbox","Outbox","State","Config","AdminQueue","AdminDone","AdminFailed","Updates"): ensure_dir(self.root/d)
        self.reload()
    def reload(self):
        bootstrap=self.store.load();remote=json_read(self.root/"Config"/"worker-config.json",{}) or {};effective=dict(bootstrap)
        for key,value in remote.items():
            if key not in REMOTE_PROTECTED:effective[key]=value
        self.cfg=effective;return self.cfg
    def save(self, **kw):
        bootstrap=self.store.load();bootstrap.update(kw);self.store.save(bootstrap);self.reload()
    def logmsg(self,m,t=1,c="M3DIAWorker"): cmtrace(self.log,m,c,t)
    def is_idle(self):
        sec=idle_seconds(); return sec>=int(self.cfg.get("idle_threshold_seconds",300)),sec
    def planning_available(self):
        planning=load_worker_planning(self.root/"Config",socket.gethostname())
        allowed,reason=planning_allows_compute(planning)
        return allowed,reason
    def current_job_dir(self):
        j=self.cfg.get("current_job_id",""); return self.root/"Inbox"/j if j else None
    def current_state_file(self):
        d=self.current_job_dir(); return d/"runtime-state.json" if d else None
    def current_job(self):
        d=self.current_job_dir(); return json_read(d/"job.json",{}) if d else {}
    def _payload(self, request_job=False, include_resources=True):
        idle,sec=self.is_idle(); planning_ok,planning_reason=self.planning_available(); r=resources(self.cfg) if include_resources else {}
        return {"WorkerId":self.cfg["worker_id"],"WorkerName":self.cfg["name"],"SharedSecret":self.cfg.get("shared_secret",""),
          "WorkerVersion":self.cfg.get("version","5.1.0"),"Hostname":socket.gethostname(),"Timestamp":iso_now(),"ConfigLatestDate":latest_local_file_date(self.root/"Config"),"IdleSeconds":sec,"IsIdle":idle,
          "CurrentJobId":self.cfg.get("current_job_id",""),"CurrentJobState":self.cfg.get("current_job_state",""),"Resources":r,
          "Capabilities":capabilities(r) if include_resources else [],"AppliedActionIds":self.cfg.get("applied_action_ids",[]),"PlanningAllowed":planning_ok,"PlanningReason":planning_reason,"RequestJob":bool(request_job and idle and planning_ok)}
    def register(self):
        base={"WorkerId":self.cfg["worker_id"],"WorkerName":self.cfg["name"],"Hostname":socket.gethostname(),"WorkerVersion":self.cfg["version"],"Timestamp":iso_now()}
        fragment=str(self.cfg.get("install_shared_fragment","") or "")
        suffix_file=str(self.cfg.get("install_secret_suffix_file","") or "")
        if fragment and suffix_file:
            challenge=http_json("POST",self.cfg["controller_url"],"/api/worker-register-challenge",base,timeout=int(self.cfg.get("connection_timeout_seconds",10)),pin_sha256=self.cfg.get("pinned_tls_sha256",""))
            if challenge.status!=200 or not isinstance(challenge.data,dict) or challenge.data.get("Status")!="OK":
                raise RuntimeError(f"registration challenge refused HTTP {challenge.status}: {challenge.data}")
            challenge_id=str(challenge.data.get("ChallengeId","") or "")
            nonce=str(challenge.data.get("Nonce","") or "")
            if not challenge_id or not nonce:raise RuntimeError("invalid registration challenge")
            install_secret=build_install_sharedsecret(fragment,read_secret_suffix(suffix_file))
            try:
                proof=registration_proof(install_secret,self.cfg["worker_id"],challenge_id,nonce)
            finally:
                install_secret=""
            body={**base,"ChallengeId":challenge_id,"Nonce":nonce,"RegistrationProof":proof}
        else:
            # Compatibility path for the immutable Windows 5.1 installer.
            body={**base,"InstallSharedSecret":self.cfg.get("install_shared_secret","")}
        r=http_json("POST",self.cfg["controller_url"],"/api/worker-register",body,timeout=int(self.cfg.get("connection_timeout_seconds",10)),pin_sha256=self.cfg.get("pinned_tls_sha256",""))
        if r.status!=200 or not isinstance(r.data,dict) or r.data.get("Status")!="OK": raise RuntimeError(f"registration refused HTTP {r.status}: {r.data}")
        self.save(shared_secret=r.data["SharedSecret"],install_shared_secret="",install_shared_fragment="",registered=True,controller_offline=False,last_successful_contact=iso_now())
        if not self.handle_config_response(r.data):raise RuntimeError("initial WORKER configuration incomplete")
        self.logmsg("Enregistrement initial accepte; SharedSecret de travail individuel recu.",1,"M3DIANetwork")
    def _post(self,path,body):
        return http_json("POST",self.cfg["controller_url"],path,body,timeout=int(self.cfg.get("connection_timeout_seconds",10)),pin_sha256=self.cfg.get("pinned_tls_sha256",""))
    def _config_request_body(self,retry_files=None):
        return {"WorkerId":self.cfg["worker_id"],"WorkerName":self.cfg["name"],"Hostname":socket.gethostname(),"WorkerVersion":self.cfg.get("version","5.1.0"),"SharedSecret":self.cfg.get("shared_secret",""),"ConfigLatestDate":latest_local_file_date(self.root/"Config"),"ConfigRetryFiles":list(retry_files or [])}
    def request_configuration(self,retry_files=None):
        r=self._post("/api/worker-config",self._config_request_body(retry_files))
        if r.status!=200 or not isinstance(r.data,dict):
            detail=r.data.get("Error","") if isinstance(r.data,dict) else r.data
            self.logmsg(f"Demande configuration refusee HTTP {r.status}: {detail}",2,"M3DIAWorkerConfig")
            return False
        return self.handle_config_response(r.data,2)
    def handle_config_response(self,reply,retry_budget=2):
        if not isinstance(reply,dict) or not reply.get("ConfigUpdate"):return True
        applied,failed,generation=apply_config_response(self.root/"Config",reply);self.reload()
        status="PARTIAL" if failed else "OK"
        ack={"WorkerId":self.cfg["worker_id"],"WorkerName":self.cfg["name"],"Hostname":socket.gethostname(),"WorkerVersion":self.cfg.get("version","5.1.0"),"SharedSecret":self.cfg.get("shared_secret",""),"ConfigGeneration":generation,"ConfigStatus":status,"FailedFiles":failed}
        response=self._post("/api/worker-config-ack",ack)
        if response.status!=200:self.logmsg(f"Accuse configuration refuse HTTP {response.status}.",2,"M3DIAWorkerConfig")
        if applied:self.logmsg(f"Configuration appliquee: {', '.join(applied)}.",1,"M3DIAWorkerConfig")
        if failed:
            self.logmsg(f"Configuration invalide, nouvelle demande ciblee: {', '.join(failed)}.",2,"M3DIAWorkerConfig")
            if retry_budget>0:
                retry=self._post("/api/worker-config",self._config_request_body(failed))
                if retry.status==200 and isinstance(retry.data,dict):return self.handle_config_response(retry.data,retry_budget-1)
            return False
        return True
    def operational_config_complete(self):
        remote=json_read(self.root/"Config"/"worker-config.json",{}) or {}
        return REQUIRED_OPERATIONAL.issubset(remote)
    def ensure_operational_config(self):
        if self.operational_config_complete():return True
        self.logmsg("Configuration de fonctionnement absente ou incomplete; demande ciblee au Controller.",2,"M3DIAWorkerConfig")
        return self.request_configuration(["worker-config.json"]) and self.operational_config_complete()
    def network_cycle(self, force=False, initial=False):
        self.reload()
        if not self.cfg.get("registered") or not self.cfg.get("shared_secret"):
            self.register(); self.reload()
        if not self.ensure_operational_config():raise RuntimeError("WORKER configuration unavailable")
        idle,sec=self.is_idle(); planning_ok,_=self.planning_available(); now=utcnow(); due_hb=True; due_work=idle and planning_ok
        hb=parse_iso(self.cfg.get("last_heartbeat_at")); wp=parse_iso(self.cfg.get("next_work_poll_at"))
        if not force and hb and (now-hb).total_seconds()<int(self.cfg["heartbeat_interval_seconds"]): due_hb=False
        if not force and wp and now<wp: due_work=False
        if not force and not due_hb and not due_work: return {"Status":"SKIP"}
        p=self._payload(request_job=due_work,include_resources=True)
        r=self._post("/api/worker-poll",p)
        if r.status!=200: raise RuntimeError(f"poll HTTP {r.status}: {r.data}")
        reply=r.data or {}; state=reply.get("ControllerState","UNKNOWN")
        updates={"controller_offline":False,"last_successful_contact":iso_now(),"controller_state":state,"last_heartbeat_at":iso_now() if due_hb or force else self.cfg.get("last_heartbeat_at","")}
        if idle: updates["next_work_poll_at"]=(now+timedelta(seconds=int(self.cfg["work_poll_interval_seconds"]))).isoformat()
        self.save(**updates)
        config_ok=self.handle_config_response(reply)
        if reply.get("NewSharedSecret"):
            old=self.cfg.get("shared_secret",""); self.save(previous_shared_secret=old,shared_secret=reply["NewSharedSecret"]); self.logmsg("Rotation SharedSecret de travail recue.",1,"M3DIANetwork")
        for act in reply.get("Actions") or []: self.apply_action(act)
        if reply.get("Job"): self.accept_job(reply["Job"])
        if not config_ok:self.logmsg("Mise a jour de configuration encore incomplete; le travail redemandera les fichiers necessaires avant execution.",2,"M3DIAWorkerConfig")
        # En LOCAL_PRIORITY, le Controller doit rester tres leger : pas de gros
        # transfert de resultats tant que son utilisateur local est actif.
        if state=="AVAILABLE": self.upload_pending_results()
        return reply
    def apply_action(self,act:dict):
        aid=str(act.get("ActionId", ""));
        if not aid or aid in self.cfg.get("applied_action_ids",[]): return
        if act.get("Type") not in ("Python","Script"): return
        work=ensure_dir(self.root/"Updates"/aid); name=safe_relative_path(str(act.get("Name") or "action.py")); script=work/name; ensure_dir(script.parent)
        script.write_bytes(base64.b64decode(act.get("ContentBase64", "")))
        for a in act.get("Attachments") or []:
            rel=safe_relative_path(str(a["RelativePath"])); p=work/rel; ensure_dir(p.parent); p.write_bytes(base64.b64decode(a["ContentBase64"]))
        req={"action_id":aid,"executable":sys.executable,"arguments":[str(script)],"working_dir":str(work),"created_at":iso_now()}
        if act.get("RunAsAdmin",True):
            atomic_json_write(self.root/"AdminQueue"/(aid+".json"),req); run_task(TASK_ADMIN)
        else: self._run_admin_request(req)
    def _run_admin_request(self,req,mark_config=True):
        aid=req["action_id"]
        try:
            p=subprocess.run([req["executable"],*req.get("arguments",[])],cwd=req.get("working_dir") or None,timeout=3600,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,**hidden_process_kwargs())
            if p.returncode: raise RuntimeError(f"exit={p.returncode}")
            if mark_config:self.mark_action_applied(aid)
            atomic_json_write(self.root/"AdminDone"/(aid+".json"),{"status":"OK","action_id":aid,"at":iso_now()})
        except Exception as e:
            atomic_json_write(self.root/"AdminFailed"/(aid+".json"),{"status":"FAILED","error":str(e),"at":iso_now()}); self.logmsg(f"Action distante {aid} en echec: {e}",3,"M3DIAAdmin")
    def mark_action_applied(self,aid):
        self.reload(); a=list(self.cfg.get("applied_action_ids",[]));
        if aid not in a: a.append(aid); a=a[-512:]; self.save(applied_action_ids=a)
    def admin_executor(self):
        # Cette commande est executee par le mecanisme privilegie preinstalle:
        # Task Scheduler/SYSTEM, systemd/root ou launchd/root. Elle traite
        # uniquement la file locale puis le Monitor reconcilie les resultats.
        for q in sorted((self.root/"AdminQueue").glob("*.json")):
            req=json_read(q,{}); q.unlink(missing_ok=True); self._run_admin_request(req,mark_config=False)
    def reconcile_admin_results(self):
        done=[]
        for marker in sorted((self.root/"AdminDone").glob("*.json")):
            data=json_read(marker,{}) or {}; aid=str(data.get("action_id") or marker.stem)
            if aid: done.append(aid)
        if done:
            self.reload(); applied=list(self.cfg.get("applied_action_ids",[]))
            changed=False
            for aid in done:
                if aid not in applied: applied.append(aid); changed=True
            if changed:self.save(applied_action_ids=applied[-512:])
    def accept_job(self,j:dict):
        jid=safe_relative_path(str(j.get("JobId") or j.get("job_id") or uuid.uuid4()))
        if self.cfg.get("current_job_id"): return
        d=ensure_dir(self.root/"Inbox"/jid); definition=j.get("Definition") or j.get("definition") or {}
        definition.setdefault("job_id",jid); atomic_json_write(d/"job.json",definition)
        for f in j.get("Files") or []:
            rel=safe_relative_path(str(f["RelativePath"])); p=d/rel; ensure_dir(p.parent); p.write_bytes(base64.b64decode(f["ContentBase64"]))
        self.save(current_job_id=jid,current_job_state="READY"); self.logmsg(f"Job {jid} recu.",1,"M3DIAJob"); run_task(TASK_JOB)
    def _command_for_job(self,job,state):
        if state.startswith("PAUSED") and job.get("resume",{}).get("command"): return job["resume"]["command"]
        return job.get("command")
    def run_job(self):
        self.reload()
        if not self.ensure_operational_config():return
        jid=self.cfg.get("current_job_id","")
        if not jid:return
        d=self.root/"Inbox"/jid; job=json_read(d/"job.json",{}); cmd=self._command_for_job(job,self.cfg.get("current_job_state",""))
        if not isinstance(cmd,list) or not cmd: self._complete_job(jid,2,"invalid command",""); return
        idle,_=self.is_idle(); planning_ok,planning_reason=self.planning_available(); r=resources(self.cfg)
        if not planning_ok:
            self.save(current_job_state="PAUSED_PLANNING"); self.logmsg(f"Job {jid} differe par planning: {planning_reason}",1,"M3DIAPlanning"); return
        if not idle or not self.job_fits(job,r): self.save(current_job_state="PAUSED_NOT_SAFE"); return
        env=os.environ.copy(); env.update({"M3DIA_AVAILABLE_CPU_THREADS":str(r["safe_available_cpu_threads"]),"M3DIA_AVAILABLE_RAM_MB":str(r["safe_available_ram_mb"]),"M3DIA_AVAILABLE_VRAM_MB":str(r["safe_available_vram_mb"]),"M3DIA_AVAILABLE_GPU_PERCENT":str(r["safe_available_gpu_percent"])})
        outdir=ensure_dir(d/"output"); stdout=open(outdir/"stdout.txt","ab",buffering=0); stderr=open(outdir/"stderr.txt","ab",buffering=0)
        kw=below_normal_kwargs();
        if os.name!="nt": kw["start_new_session"]=True
        try:
            with KeepAwake():
                proc=subprocess.Popen([str(x) for x in cmd],cwd=str(d),env=env,stdout=stdout,stderr=stderr,**kw)
                atomic_json_write(d/"runtime-state.json",{"pid":proc.pid,"started_at":iso_now(),"state":"RUNNING"}); self.save(current_job_state="RUNNING")
                run_task(TASK_GUARD)
                rc=proc.wait()
            self.reload()
            if str(self.cfg.get("current_job_state","")).startswith("PAUSED"): return
            self._complete_job(jid,rc,"",str(outdir))
        except Exception as e: self._complete_job(jid,3,str(e),str(outdir))
        finally: stdout.close(); stderr.close()
    def job_fits(self,job,r):
        req=job.get("requirements") or job.get("Requirements") or {}
        if not r.get("power_policy_safe"):return False
        checks=(("cpu_threads","safe_available_cpu_threads"),("cpu_percent","safe_available_cpu_percent"),("ram_mb","safe_available_ram_mb"),("disk_mb","safe_available_disk_mb"),("gpu_percent","safe_available_gpu_percent"),("vram_mb","safe_available_vram_mb"))
        for a,b in checks:
            v=int(req.get(a,req.get(''.join([a.split('_')[0].title(), ''.join(x.title() for x in a.split('_')[1:])]),0)) or 0)
            if v>int(r.get(b,0)):return False
        if req.get("gpu_required") or req.get("GpuRequired"):
            if not r.get("gpu_compute_available"):return False
        return True
    def running_job_still_safe(self,job,r):
        # Ne compare PAS les besoins initiaux du job a la capacite restante :
        # le job lui-meme consomme justement cette capacite. On verifie ici
        # que les reserves de securite promises a Windows restent intactes.
        if not r.get("power_policy_safe"): return False
        if int(r.get("ram_available_now_mb",0)) < int(r.get("ram_reserve_mb",0)): return False
        if int(r.get("disk_free_now_mb",0)) < int(r.get("disk_reserve_mb",self.cfg.get("disk_reserve_minimum_mb",8192))): return False
        req=job.get("requirements") or job.get("Requirements") or {}
        if req.get("gpu_required") or req.get("GpuRequired") or int(req.get("vram_mb",0) or 0)>0:
            gpus=r.get("gpus") or []
            if not gpus:return False
            # Au moins un GPU doit conserver sa reserve VRAM. La charge GPU
            # n'est pas un critere d'arret : elle peut provenir du job M3DIA.
            if not any(int(g.get("vram_free_now_mb",0)) >= int(g.get("vram_reserve_mb",0)) for g in gpus):return False
        return True

    def checkpoint(self,reason="USER_ACTIVE"):
        self.reload(); d=self.current_job_dir();
        if not d:return
        st=json_read(d/"runtime-state.json",{}); pid=int(st.get("pid",0) or 0); job=json_read(d/"job.json",{})
        cp=(job.get("checkpoint") or {}).get("command")
        if isinstance(cp,list) and cp:
            with contextlib.suppress(Exception): subprocess.run([str(x) for x in cp],cwd=str(d),timeout=2,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,**hidden_process_kwargs())
        if process_alive(pid): terminate_tree(pid)
        atomic_json_write(d/"runtime-state.json",{"pid":0,"state":"PAUSED","reason":reason,"at":iso_now()}); self.save(current_job_state=f"PAUSED_{reason}")
        self.logmsg(f"Job {self.cfg.get('current_job_id')} checkpoint/arrete: {reason}",1,"M3DIAGuard")
    def guard(self):
        self.reload()
        if self.cfg.get("current_job_state")!="RUNNING":return
        idle,_=self.is_idle(); planning_ok,planning_reason=self.planning_available(); job=self.current_job(); r=resources(self.cfg,cpu_sample_seconds=.2)
        if not idle:self.checkpoint("USER_ACTIVE");return
        if not planning_ok:
            self.logmsg(f"Job {self.cfg.get('current_job_id')} arrete par planning: {planning_reason}",1,"M3DIAPlanning")
            self.checkpoint("PLANNING");return
        if not self.running_job_still_safe(job,r):self.checkpoint("RESOURCES");return
        # Checkpoint leger periodique si le moteur du job en expose un. Cela
        # limite la perte lors d'hibernation/coupure brutale sans gros travail
        # de derniere seconde.
        d=self.current_job_dir(); st=json_read(d/"runtime-state.json",{}) if d else {}; cp=(job.get("checkpoint") or {}).get("command")
        last=parse_iso(st.get("last_checkpoint_at")); due=not last or (utcnow()-last).total_seconds()>=int(self.cfg.get("checkpoint_interval_seconds",60))
        if due and isinstance(cp,list) and cp:
            try:
                subprocess.run([str(x) for x in cp],cwd=str(d),timeout=int((job.get("checkpoint") or {}).get("timeout_seconds",2)),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,**hidden_process_kwargs())
                st["last_checkpoint_at"]=iso_now(); atomic_json_write(d/"runtime-state.json",st)
            except Exception:pass
        defer_task(TASK_GUARD,float(self.cfg.get("resource_guard_interval_seconds",1)))
    def _complete_job(self,jid,rc,error,outdir):
        d=self.root/"Inbox"/jid; result_paths=(json_read(d/"job.json",{}).get("result_paths") or ["output"])
        atomic_json_write(d/"job-result.json",{"job_id":jid,"exit_code":rc,"error":error,"completed_at":iso_now()})
        manifest={"job_id":jid,"exit_code":rc,"error":error,"result_paths":result_paths,"created_at":iso_now()}; atomic_json_write(self.root/"Outbox"/(jid+".json"),manifest)
        self.save(current_job_state="RESULT_PENDING"); self.logmsg(f"Job {jid} termine rc={rc}; resultat conserve jusqu'a acceptation Controller.",1,"M3DIAJob")
        try:self.network_cycle(force=True)
        except Exception:self.recover(from_failure=True)
    def _result_files(self,jid,manifest):
        d=self.root/"Inbox"/jid; files=[]
        for rp in manifest.get("result_paths",[]):
            p=d/safe_relative_path(rp)
            if p.is_file(): files.append((p,p.relative_to(d).as_posix()))
            elif p.is_dir():
                for f in p.rglob("*"):
                    if f.is_file(): files.append((f,f.relative_to(d).as_posix()))
        jr=d/"job-result.json"
        if jr.exists(): files.append((jr,"job-result.json"))
        return files
    def upload_pending_results(self):
        for mf in sorted((self.root/"Outbox").glob("*.json")):
            m=json_read(mf,{}); jid=m.get("job_id") or mf.stem; self._upload_result(jid,m,mf)
    def _upload_result(self,jid,m,mf):
        files=self._result_files(jid,m); summary=[{"path":rel,"size":p.stat().st_size,"sha256":sha256_file(p)} for p,rel in files]
        common={"WorkerId":self.cfg["worker_id"],"WorkerName":self.cfg["name"],"SharedSecret":self.cfg["shared_secret"],"JobId":jid}
        r=self._post("/api/worker-result-begin",{**common,"Files":summary,"ExitCode":m.get("exit_code",0),"Error":m.get("error","")})
        if r.status!=200: raise RuntimeError(f"result begin HTTP {r.status}")
        chunk_size=int(self.cfg.get("result_chunk_bytes",4194304))
        for p,rel in files:
            offset=0
            with open(p,"rb") as f:
                while True:
                    # Le proprietaire du PC reste prioritaire, y compris sur
                    # un gros envoi de resultat. Le manifest sera recommence
                    # proprement au prochain cycle.
                    if not self.is_idle()[0]:
                        self.logmsg(f"Upload resultat {jid} differe: utilisateur actif.",1,"M3DIAResult")
                        return
                    b=f.read(chunk_size)
                    if not b:break
                    rr=self._post("/api/worker-result-chunk",{**common,"Path":rel,"Offset":offset,"DataBase64":base64.b64encode(b).decode(),"ChunkSha256":sha256_bytes(b)})
                    if rr.status!=200: raise RuntimeError(f"chunk HTTP {rr.status}")
                    offset+=len(b)
        rr=self._post("/api/worker-result-finalize",common)
        if rr.status!=200: raise RuntimeError(f"finalize HTTP {rr.status}")
        data=rr.data or {}
        if data.get("Status")=="ACCEPTED":
            if data.get("DeleteInbox",False): shutil.rmtree(self.root/"Inbox"/jid,ignore_errors=True)
            mf.unlink(missing_ok=True); self.save(current_job_id="",current_job_state="",last_job_id=jid,last_job_status="ACCEPTED"); self.logmsg(f"Resultat {jid} accepte par Controller; Inbox supprimee={bool(data.get('DeleteInbox'))}.",1,"M3DIAResult")
        elif data.get("Status")=="RETRY":
            jf=self.root/"Inbox"/jid/"job.json"; job=json_read(jf,{}); atomic_json_write(jf,merge_dict(job,data.get("JobPatch") or {})); self.save(current_job_state="PAUSED_RESULT_REJECTED")
    def recover(self,from_failure=False):
        self.reload(); cur=self.cfg.get("controller_url",""); pin=self.cfg.get("pinned_tls_sha256",""); ok,_=health_check(cur,self.cfg.get("health_timeout_seconds",3),pin)
        if ok:
            self.save(controller_offline=False,next_retry_at="");
            try:self.network_cycle(force=True)
            except Exception as e:self.logmsg(f"Controller joignable mais echange metier en erreur: {e}",2,"M3DIARecovery")
            return True
        # ONLY after current controller is really unreachable.
        manifest=get_rendezvous(self.cfg.get("rendezvous_url",""),self.cfg.get("health_timeout_seconds",3))
        if manifest:
            gen=int(manifest.get("generation",0) or 0); candidate=manifest.get("controllerUrl") or manifest.get("ControllerUrl") or ""; cpin=manifest.get("pinnedTlsSha256") or manifest.get("PinnedTlsSha256") or ""
            if gen>int(self.cfg.get("last_applied_rendezvous_generation",0)) and candidate:
                cok,_=health_check(candidate,self.cfg.get("health_timeout_seconds",3),cpin)
                if cok:
                    old=(cur,pin,self.cfg.get("shared_secret","")); self.save(pending_controller_url=candidate,pending_pinned_tls_sha256=cpin)
                    try:
                        self.save(controller_url=candidate,pinned_tls_sha256=cpin)
                        self.reload()
                        try:self.network_cycle(force=True)
                        except Exception:
                            token=manifest.get("migrationToken") or manifest.get("MigrationToken") or ""
                            if not token:raise
                            rr=http_json("POST",candidate,"/api/worker-migrate",{"WorkerId":self.cfg["worker_id"],"WorkerName":self.cfg["name"],"MigrationToken":token,"WorkerVersion":self.cfg["version"]},timeout=self.cfg["connection_timeout_seconds"],pin_sha256=cpin)
                            if rr.status!=200 or not rr.data or rr.data.get("Status")!="OK":raise RuntimeError("migration refused")
                            self.save(shared_secret=rr.data["SharedSecret"],registered=True); self.reload(); self.network_cycle(force=True)
                        self.save(previous_controller_url=old[0],previous_pinned_tls_sha256=old[1],previous_shared_secret=old[2],pending_controller_url="",pending_pinned_tls_sha256="",last_applied_rendezvous_generation=gen,controller_offline=False,next_retry_at="")
                        self.logmsg(f"Migration Controller validee generation={gen}: {candidate}",1,"M3DIARecovery"); return True
                    except Exception as e:
                        self.save(controller_url=old[0],pinned_tls_sha256=old[1],shared_secret=old[2],pending_controller_url="",pending_pinned_tls_sha256=""); self.logmsg(f"Migration candidate annulee: {e}",2,"M3DIARecovery")
        next_at=utcnow()+timedelta(hours=int(self.cfg.get("retry_interval_hours",12))); self.save(controller_offline=True,next_retry_at=next_at.isoformat()); self.schedule_retry(next_at); self.logmsg(f"Controller indisponible; prochain essai leger a {next_at.isoformat()}.",2,"M3DIARecovery"); return False
    def schedule_retry(self,when):
        if os.name=="nt":
            from .installer import windows_schedule_once
            py=Path(sys.executable)
            pyw=py if py.name.lower()=="pythonw.exe" else py.with_name("pythonw.exe")
            if not pyw.is_file():
                raise RuntimeError(f"pythonw.exe introuvable pour le retry Worker: {pyw}")
            wrapper=self.root/"worker_main.py"
            windows_schedule_once(
                TASK_RETRY,
                [str(pyw),str(wrapper),"retry"],
                when,
                run_as_system=False,
                wake=not bool(self.cfg.get("is_portable",False)),
                log_path=self.log,
            )
        else:
            # Le timer systemd Worker gère les réveils légers côté Linux.
            pass
    def monitor(self,reschedule=True):
        self.reload(); self.reconcile_admin_results()
        if self.cfg.get("controller_offline"):
            retry_at=parse_iso(self.cfg.get("next_retry_at"))
            if retry_at and utcnow()>=retry_at:
                self.recover(from_failure=False); self.reload()
        idle,_=self.is_idle()
        if not idle:
            if self.cfg.get("current_job_state")=="RUNNING":run_task(TASK_GUARD)
            # Le heartbeat reste du a 5 minutes meme si l'utilisateur est actif.
            # network_cycle n'enverra pas de demande de travail dans cet etat.
            if not self.cfg.get("controller_offline"):
                try:self.network_cycle(force=False)
                except Exception:self.recover(from_failure=True)
        else:
            if str(self.cfg.get("current_job_state","")).startswith("PAUSED"):run_task(TASK_JOB)
            if not self.cfg.get("controller_offline"):
                try:self.network_cycle(force=False)
                except Exception:self.recover(from_failure=True)
        if reschedule and os.name=="nt": defer_task(TASK_MONITOR,1)
    def wake_poll(self):
        self.reload()
        if self.cfg.get("controller_offline"):return
        try:self.network_cycle(force=False)
        except Exception:self.recover(from_failure=True)
    def session_end(self,reason="SESSION_END"):
        if self.cfg.get("current_job_state")=="RUNNING":self.checkpoint(reason)
    def recover_crash(self):
        self.reload(); d=self.current_job_dir()
        if not d:return
        st=json_read(d/"runtime-state.json",{}); pid=int(st.get("pid",0) or 0)
        if self.cfg.get("current_job_state")=="RUNNING" and not process_alive(pid): self.save(current_job_state="PAUSED_REBOOT_RECOVERY")

def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument("command",choices=["monitor","wake-poll","retry","network","job","guard","admin-executor","session-end","recover-crash","status"]); p.add_argument("--config"); p.add_argument("--reason",default="SESSION_END"); p.add_argument("--no-reschedule",action="store_true"); a=p.parse_args(argv); w=Worker(a.config)
    try:
        if a.command=="monitor":w.monitor(not a.no_reschedule)
        elif a.command=="wake-poll":w.wake_poll()
        elif a.command=="retry":w.recover()
        elif a.command=="network":w.network_cycle(force=True)
        elif a.command=="job":w.run_job()
        elif a.command=="guard":w.guard()
        elif a.command=="admin-executor":w.admin_executor()
        elif a.command=="session-end":w.session_end(a.reason)
        elif a.command=="recover-crash":w.recover_crash()
        elif a.command=="status":print(json.dumps(w.store.load(),indent=2))
    except Exception as e: w.logmsg(f"{a.command}: {e}",3,"M3DIAWorker"); raise
if __name__=="__main__": main()
