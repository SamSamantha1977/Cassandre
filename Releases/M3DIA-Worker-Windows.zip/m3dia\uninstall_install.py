from __future__ import annotations

import base64
import json
import ntpath
import os
import sys
from pathlib import Path

from .common import cmtrace, ensure_dir

IS_WINDOWS = os.name == "nt"

TASKS = [
    "M3DIACompute Worker Monitor",
    "M3DIACompute Worker WakePoll",
    "M3DIACompute Worker Retry",
    "M3DIACompute Worker JobRunner",
    "M3DIACompute Worker JobGuard",
    "M3DIACompute Worker AdminExecutor",
    # anciens noms connus
    "M3DIACompute Worker Presence",
    "M3DIACompute Worker",
]


def _cmd_text(config: dict) -> str:
    known = str(config["python_executable"]).replace('"', '""')
    sid = str(config.get("owner_sid") or "").replace('"', "")
    root = str(config["install_root"])
    bootstrap = str(config["bootstrap_root"])
    localapp = str(config["localappdata_root"])
    canonical_cmd = ntpath.join(str(config["uninstall_root"]), "uninstall-worker.cmd")
    tasks = " ".join(f'"{x}"' for x in config["tasks"])

    ps_elevate = (
        "Start-Process -FilePath $env:ComSpec "
        f"-ArgumentList @('/d','/c','\\\"{canonical_cmd}\\\" __nativeelevated') "
        "-Verb RunAs -Wait -WindowStyle Hidden"
    )
    ps_elevate_b64 = base64.b64encode(ps_elevate.encode("utf-16le")).decode("ascii")

    owner_registry = f'HKU\\\\{sid}\\\\Software\\\\M3DIA\\\\Compute' if sid else 'HKCU\\\\Software\\\\M3DIA\\\\Compute'
    logoff_key = (
        f'HKU\\\\{sid}\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Group Policy\\\\Scripts\\\\Logoff\\\\0\\\\0'
        if sid else
        'HKCU\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Group Policy\\\\Scripts\\\\Logoff\\\\0\\\\0'
    )

    lines = [
        "@echo off",
        "setlocal EnableExtensions",
        'set "SCRIPT=%~dp0uninstall-worker.py"',
        'set "PYEXE="',
        f'set "PYKNOWN={known}"',
        "",
        'if defined PYKNOWN if exist "%PYKNOWN%" call :TryPython "%PYKNOWN%"',
        "if defined PYEXE goto RunPython",
        "",
        "for %%N in (python.exe python3.exe) do (",
        "    for /f \"delims=\" %%P in ('where %%N 2^>nul') do (",
        '        if not defined PYEXE call :TryPython "%%~fP"',
        "    )",
        ")",
        "if defined PYEXE goto RunPython",
        "",
        "where py.exe >nul 2>&1",
        "if not errorlevel 1 (",
        '    py.exe -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1',
        "    if not errorlevel 1 goto RunPy",
        ")",
        "",
        'for /d %%D in ("%LOCALAPPDATA%\\Programs\\Python\\Python*") do (',
        '    if not defined PYEXE if exist "%%~fD\\python.exe" call :TryPython "%%~fD\\python.exe"',
        ")",
        "if defined PYEXE goto RunPython",
        "",
        'for /d %%D in ("%ProgramFiles%\\Python*") do (',
        '    if not defined PYEXE if exist "%%~fD\\python.exe" call :TryPython "%%~fD\\python.exe"',
        ")",
        "if defined PYEXE goto RunPython",
        "",
        "for %%H in (HKCU HKLM) do (",
        "    for /f \"tokens=2,*\" %%A in ('reg.exe query \"%%H\\Software\\Python\\PythonCore\" /s /v ExecutablePath 2^>nul ^| findstr /i /c:\"ExecutablePath\"') do (",
        '        if not defined PYEXE call :TryPython "%%~B"',
        "    )",
        ")",
        "if defined PYEXE goto RunPython",
        "",
        "goto NativeNeedElevation",
        "",
        ":TryPython",
        '"%~1" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1',
        'if not errorlevel 1 set "PYEXE=%~1"',
        "exit /b 0",
        "",
        ":RunPython",
        '"%PYEXE%" "%SCRIPT%"',
        "if errorlevel 1 goto NativeNeedElevation",
        "exit /b 0",
        "",
        ":RunPy",
        'py.exe -3 "%SCRIPT%"',
        "if errorlevel 1 goto NativeNeedElevation",
        "exit /b 0",
        "",
        ":NativeNeedElevation",
        "fltmc.exe >nul 2>&1",
        "if not errorlevel 1 goto NativeFallback",
        "where powershell.exe >nul 2>&1",
        "if errorlevel 1 exit /b 0",
        f'powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand {ps_elevate_b64} >nul 2>&1',
        "exit /b 0",
        "",
        ":NativeFallback",
        f"for %%T in ({tasks}) do (",
        '    schtasks.exe /End /TN "%%~T" >nul 2>&1',
        '    schtasks.exe /Delete /TN "%%~T" /F >nul 2>&1',
        ")",
        f'reg.exe query "{logoff_key}" /s 2>nul | findstr /i /c:"M3DIA" /c:"worker_main.py" >nul 2>&1 && reg.exe delete "{logoff_key}" /f >nul 2>&1',
        f'reg.exe delete "{owner_registry}" /f >nul 2>&1',
        f'where powershell.exe >nul 2>&1 && powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -Command "$ErrorActionPreference=\'SilentlyContinue\'; Remove-MpPreference -ExclusionPath \'{root}\' -Force -ErrorAction SilentlyContinue; exit 0" >nul 2>&1',
        f'rd /s /q "{localapp}" >nul 2>&1',
        f'rd /s /q "{root}" >nul 2>&1',
        f'rd /s /q "{bootstrap}" >nul 2>&1',
        "exit /b 0",
        "",
    ]
    return "\r\n".join(lines)


def install_worker_uninstaller(root: Path, owner_user: str, owner_sid: str, log_path: Path) -> Path | None:
    if not IS_WINDOWS:
        return None

    programdata = Path(os.getenv("PROGRAMDATA", r"C:\ProgramData"))
    localapp = Path(os.getenv("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "M3DIACompute"
    uninstall_root = ensure_dir(programdata / "M3DIACompute-Uninstall-Worker")

    config = {
        "python_executable": sys.executable,
        "install_root": str(root),
        "bootstrap_root": str(programdata / "M3DIACompute-Bootstrap"),
        "localappdata_root": str(localapp),
        "uninstall_root": str(uninstall_root),
        "owner_user": str(owner_user),
        "owner_sid": str(owner_sid),
        "tasks": TASKS,
        "defender_paths": [str(root)],
        "registry_paths": [
            (f"HKU\\{owner_sid}\\Software\\M3DIA\\Compute" if owner_sid else r"HKCU\Software\M3DIA\Compute")
        ],
        "install_dirs": [
            str(localapp),
            str(root),
            str(programdata / "M3DIACompute-Bootstrap"),
        ],
        "logoff_key": (
            f"HKU\\{owner_sid}\\Software\\Microsoft\\Windows\\CurrentVersion\\Group Policy\\Scripts\\Logoff\\0\\0"
            if owner_sid else
            r"HKCU\Software\Microsoft\Windows\CurrentVersion\Group Policy\Scripts\Logoff\0\0"
        ),
    }

    wrapper = uninstall_root / "uninstall-worker.py"
    wrapper.write_text(
        "from __future__ import annotations\n"
        "import json, sys\n"
        "from pathlib import Path\n"
        f"APP_PATH={str(root / 'app')!r}\n"
        f"CONFIG=json.loads({json.dumps(json.dumps(config, ensure_ascii=False))})\n"
        "sys.path.insert(0, APP_PATH)\n"
        "from m3dia.uninstaller import uninstall_worker\n"
        "raise SystemExit(uninstall_worker(CONFIG, Path(__file__).resolve(), '--elevated' in sys.argv))\n",
        encoding="utf-8",
    )

    cmd_path = uninstall_root / "uninstall-worker.cmd"
    cmd_path.write_text(_cmd_text(config), encoding="utf-8")

    # Raccourci local sans AUCUN paramètre utilisateur.
    local_cmd = root / "uninstall-worker.cmd"
    local_cmd.write_text(
        "@echo off\r\n"
        f'start "" /b "%ComSpec%" /d /c ""{cmd_path}"\r\n'
        "exit /b 0\r\n",
        encoding="utf-8",
    )

    cmtrace(log_path, f"Desinstalleur Worker sans parametre cree: {local_cmd}", "Installer")
    cmtrace(log_path, f"Desinstalleur Worker canonique: {cmd_path}", "Installer")
    return local_cmd
