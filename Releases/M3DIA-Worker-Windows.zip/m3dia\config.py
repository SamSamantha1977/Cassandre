from __future__ import annotations
import os, platform, uuid
from pathlib import Path
from typing import Any
from .common import INSTALL_SHARED_SECRET_DEFAULT, atomic_json_write, json_read
IS_WINDOWS=os.name=="nt"

def worker_default_path()->Path:
    if os.getenv("M3DIA_WORKER_CONFIG"):return Path(os.environ["M3DIA_WORKER_CONFIG"])
    base=(Path(os.getenv("LOCALAPPDATA",str(Path.home()/"AppData"/"Local")))/"M3DIACompute") if IS_WINDOWS else (Path(os.getenv("XDG_CONFIG_HOME",str(Path.home()/".config")))/"m3dia")
    return base/"worker.json"

def controller_default_path()->Path:
    if os.getenv("M3DIA_CONTROLLER_CONFIG"):return Path(os.environ["M3DIA_CONTROLLER_CONFIG"])
    if IS_WINDOWS:return Path(os.getenv("PROGRAMDATA",r"C:\ProgramData"))/"M3DIACompute-Controller"/"controller.json"
    return Path("/etc/m3dia/controller.json") if hasattr(os,"geteuid") and os.geteuid()==0 else Path(os.getenv("XDG_CONFIG_HOME",str(Path.home()/".config")))/"m3dia"/"controller.json"

def default_worker(install_root:str="")->dict:
    if not install_root:install_root=str((Path(os.getenv("PROGRAMDATA",r"C:\ProgramData"))/"M3DIACompute") if IS_WINDOWS else (Path.home()/".local/share/m3dia-compute"))
    # Only enrollment, Controller connectivity and local execution state are
    # installed. Operational settings arrive as complete files from Controller.
    return {"version":"5.1.0","name":platform.node() or "worker","worker_id":str(uuid.uuid4()),"controller_url":"https://ywen.freeboxos.fr:9000","previous_controller_url":"","pending_controller_url":"","pinned_tls_sha256":"5366419B579502BA654A550FEC99A49F74F580CF1AC58E123C6213245630C289","previous_pinned_tls_sha256":"","pending_pinned_tls_sha256":"","install_shared_secret":"","install_shared_fragment":"","install_secret_suffix_file":"","shared_secret":"","previous_shared_secret":"","registered":False,"install_root":install_root,"controller_offline":False,"next_retry_at":"","last_heartbeat_at":"","next_work_poll_at":"","last_successful_contact":"","last_applied_rendezvous_generation":0,"current_job_id":"","current_job_state":"","applied_action_ids":[],"is_portable":False}

def default_controller(project_root:str="",install_root:str="")->dict:
    if not project_root:project_root=r"D:\M3DIACompute" if IS_WINDOWS else "/var/lib/m3dia-compute"
    if not install_root:install_root=str((Path(os.getenv("PROGRAMDATA",r"C:\ProgramData"))/"M3DIACompute-Controller") if IS_WINDOWS else Path("/opt/m3dia-controller"))
    return {"version":"4.0.0","listen_host":"0.0.0.0","listen_port":9000,"public_url":"https://ywen.freeboxos.fr:9000","project_root":project_root,"install_root":install_root,"install_shared_secret":INSTALL_SHARED_SECRET_DEFAULT,"secret_rotation_days":7,"controller_idle_threshold_seconds":300,"activity_state_path":str(Path(install_root)/"State"/"activity.json"),"tls_cert":str(Path(install_root)/"tls"/"controller.crt.pem"),"tls_key":str(Path(install_root)/"tls"/"controller.key.pem"),"workers_db":str(Path(project_root)/"ControllerState"/"workers.json"),"send_root":str(Path(project_root)/"ConfigCommuneWorkers"/"send"),"jobs_root":str(Path(project_root)/"Jobs"),"log_file":str(Path(install_root)/"Logs"/"controller.cmtrace.log"),"migration_token":"","local_compute_enabled":True,"manual_local_priority":False,"resource_disk_path":project_root,"cpu_reserve_percent":20,"ram_reserve_percent":20,"ram_reserve_minimum_mb":4096,"gpu_reserve_percent":15,"vram_reserve_percent":10,"vram_reserve_minimum_mb":1024,"disk_reserve_minimum_mb":8192,"allow_compute_on_battery":False,"minimum_battery_percent":50,"local_resource_guard_interval_seconds":1,"checkpoint_interval_seconds":60}


WORKER_BOOTSTRAP_KEYS={
    "version","name","worker_id","controller_url","previous_controller_url","pending_controller_url",
    "pinned_tls_sha256","previous_pinned_tls_sha256","pending_pinned_tls_sha256",
    "install_shared_secret","install_shared_fragment","install_secret_suffix_file","shared_secret","previous_shared_secret","registered","install_root",
    "controller_offline","next_retry_at","last_heartbeat_at","next_work_poll_at",
    "last_successful_contact","last_applied_rendezvous_generation","current_job_id",
    "current_job_state","applied_action_ids","is_portable","controller_state","last_job_id",
    "last_job_status"
}


def bootstrap_worker_state(existing:dict,defaults:dict)->dict:
    clean=dict(defaults)
    for key in WORKER_BOOTSTRAP_KEYS:
        if key in existing:clean[key]=existing[key]
    clean["version"]="5.1.0"
    return clean

class JsonConfig:
    def __init__(self,path:str|Path,defaults:dict):self.path=Path(path);self.defaults=defaults
    def load(self)->dict:
        d=dict(self.defaults);d.update(json_read(self.path,{}) or {});return d
    def save(self,data:dict)->None:atomic_json_write(self.path,data)
    def update(self,**kwargs:Any)->dict:d=self.load();d.update(kwargs);self.save(d);return d

class RegistryJsonConfig:
    def __init__(self,hive_name:str,key_path:str,defaults:dict):self.hive_name=hive_name;self.key_path=key_path;self.defaults=defaults
    def _hive(self):
        import winreg
        return winreg.HKEY_CURRENT_USER if self.hive_name=="HKCU" else winreg.HKEY_LOCAL_MACHINE
    def load(self)->dict:
        import winreg,json
        d=dict(self.defaults)
        try:
            with winreg.OpenKey(self._hive(),self.key_path,0,winreg.KEY_READ) as k:raw=winreg.QueryValueEx(k,"ConfigJson")[0];d.update(json.loads(raw))
        except OSError:pass
        return d
    def save(self,data:dict)->None:
        import winreg,json
        with winreg.CreateKeyEx(self._hive(),self.key_path,0,winreg.KEY_SET_VALUE) as k:winreg.SetValueEx(k,"ConfigJson",0,winreg.REG_SZ,json.dumps(data,separators=(",",":"),ensure_ascii=False))
    def update(self,**kwargs:Any)->dict:d=self.load();d.update(kwargs);self.save(d);return d

def worker_store(path:str|Path|None=None,defaults:dict|None=None):
    d=defaults or default_worker()
    if path:return JsonConfig(path,d)
    if IS_WINDOWS and not os.getenv("M3DIA_WORKER_CONFIG"):return RegistryJsonConfig("HKCU",r"Software\M3DIA\Compute\Worker",d)
    return JsonConfig(worker_default_path(),d)

def controller_store(path:str|Path|None=None,defaults:dict|None=None):
    d=defaults or default_controller()
    if path:return JsonConfig(path,d)
    if IS_WINDOWS and not os.getenv("M3DIA_CONTROLLER_CONFIG"):return RegistryJsonConfig("HKLM",r"SOFTWARE\M3DIA\Compute\MINIPC",d)
    return JsonConfig(controller_default_path(),d)
