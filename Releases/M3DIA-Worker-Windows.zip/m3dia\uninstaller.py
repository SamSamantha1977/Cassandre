from __future__ import annotations

import contextlib
import ctypes
import os
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from ctypes import wintypes

IS_WINDOWS = os.name == "nt"


def log(message: str, level: int = 1) -> None:
    try:
        p = Path(tempfile.gettempdir()) / "M3DIACompute-worker-uninstall.cmtrace.log"
        now = datetime.now()
        safe = str(message).replace("]]>", "] ]>")
        line = (
            f'<![LOG[{safe}]LOG]!>'
            f'<time="{now:%H:%M:%S.%f}" date="{now:%m-%d-%Y}" '
            f'component="Uninstaller" context="" type="{int(level)}" '
            f'thread="{os.getpid()}" file="">'
        )
        line = line.replace(now.strftime("%H:%M:%S.%f"), now.strftime("%H:%M:%S.%f")[:-3])
        with p.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def hidden_kwargs() -> dict:
    if not IS_WINDOWS:
        return {}
    flags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
    out = {"creationflags": flags}
    with contextlib.suppress(Exception):
        si = subprocess.STARTUPINFO()
        si.dwFlags |= int(getattr(subprocess, "STARTF_USESHOWWINDOW", 0x00000001))
        si.wShowWindow = int(getattr(subprocess, "SW_HIDE", 0))
        out["startupinfo"] = si
    return out


def run(command: list[str], timeout: float = 30.0) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            [str(x) for x in command],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="replace",
            timeout=timeout,
            check=False,
            **hidden_kwargs(),
        )
    except Exception as exc:
        return subprocess.CompletedProcess(command, 1, "", f"{type(exc).__name__}: {exc}")


def is_admin() -> bool:
    if not IS_WINDOWS:
        return True
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def elevate_and_wait(wrapper_path: Path) -> int:
    SEE_MASK_NOCLOSEPROCESS = 0x00000040
    SW_HIDE = 0
    INFINITE = 0xFFFFFFFF

    class SHELLEXECUTEINFOW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD), ("fMask", ctypes.c_ulong),
            ("hwnd", wintypes.HWND), ("lpVerb", wintypes.LPCWSTR),
            ("lpFile", wintypes.LPCWSTR), ("lpParameters", wintypes.LPCWSTR),
            ("lpDirectory", wintypes.LPCWSTR), ("nShow", ctypes.c_int),
            ("hInstApp", wintypes.HINSTANCE), ("lpIDList", ctypes.c_void_p),
            ("lpClass", wintypes.LPCWSTR), ("hkeyClass", wintypes.HKEY),
            ("dwHotKey", wintypes.DWORD), ("hIcon", wintypes.HANDLE),
            ("hProcess", wintypes.HANDLE),
        ]

    exe = Path(sys.executable)
    pythonw = exe if exe.name.lower() == "pythonw.exe" else exe.with_name("pythonw.exe")
    if pythonw.is_file():
        exe = pythonw
    params = subprocess.list2cmdline([str(wrapper_path), "--elevated"])

    sei = SHELLEXECUTEINFOW()
    sei.cbSize = ctypes.sizeof(sei)
    sei.fMask = SEE_MASK_NOCLOSEPROCESS
    sei.lpVerb = "runas"
    sei.lpFile = str(exe)
    sei.lpParameters = params
    sei.lpDirectory = str(wrapper_path.parent)
    sei.nShow = SW_HIDE

    log("Elevation UAC demandee.")
    if not ctypes.windll.shell32.ShellExecuteExW(ctypes.byref(sei)):
        code = int(ctypes.GetLastError())
        log(f"Elevation UAC impossible/annulee: Win32={code}.", 2)
        return code or 1
    try:
        ctypes.windll.kernel32.WaitForSingleObject(sei.hProcess, INFINITE)
        exit_code = wintypes.DWORD(1)
        ctypes.windll.kernel32.GetExitCodeProcess(sei.hProcess, ctypes.byref(exit_code))
        return int(exit_code.value)
    finally:
        with contextlib.suppress(Exception):
            ctypes.windll.kernel32.CloseHandle(sei.hProcess)


def remove_task(name: str) -> None:
    run(["schtasks.exe", "/End", "/TN", name])
    r = run(["schtasks.exe", "/Delete", "/TN", name, "/F"])
    log(f"Tache traitee: {name}; code={r.returncode}.")


def remove_registry(path: str) -> None:
    r = run(["reg.exe", "delete", path, "/f"])
    log(f"Registre traite: {path}; code={r.returncode}.")


def remove_defender(path: str) -> None:
    ps = shutil.which("powershell.exe")
    if not ps:
        candidate = Path(os.getenv("SystemRoot", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
        if candidate.is_file():
            ps = str(candidate)
    if not ps:
        log(f"PowerShell absent: exclusion Defender ignoree pour {path}.", 2)
        return
    literal = str(path).replace("'", "''")
    command = (
        "$ErrorActionPreference='SilentlyContinue';"
        "$cmd=Get-Command Get-MpPreference -ErrorAction SilentlyContinue;"
        "if($cmd){$p=(Get-MpPreference -ErrorAction SilentlyContinue).ExclusionPath;"
        f"if($p -contains '{literal}'){{Remove-MpPreference -ExclusionPath '{literal}' -Force -ErrorAction SilentlyContinue}}"
        "};exit 0"
    )
    r = run([
        ps, "-NoLogo", "-NoProfile", "-NonInteractive",
        "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-Command", command
    ])
    log(f"Exclusion Defender traitee: {path}; code={r.returncode}.")


def remove_logoff_handler(path: str) -> None:
    q = run(["reg.exe", "query", path, "/s"])
    text = (q.stdout or "") + "\n" + (q.stderr or "")
    if q.returncode != 0:
        log(f"Handler logoff deja absent: {path}.")
        return
    low = text.lower()
    if "m3dia" not in low and "worker_main.py" not in low:
        log(f"Handler logoff non M3DIA conserve: {path}.")
        return
    r = run(["reg.exe", "delete", path, "/f"])
    log(f"Handler logoff M3DIA traite: {path}; code={r.returncode}.")


def remove_tree(path: str) -> None:
    p = Path(path)
    if not p.exists():
        log(f"Dossier deja absent: {p}.")
        return
    last = ""
    for _attempt in range(5):
        try:
            shutil.rmtree(p, ignore_errors=False)
        except FileNotFoundError:
            return
        except Exception as exc:
            last = f"{type(exc).__name__}: {exc}"
        if not p.exists():
            log(f"Dossier supprime: {p}.")
            return
        time.sleep(0.4)
    log(f"Dossier encore present apres tentatives, poursuite: {p}; {last}.", 2)


def schedule_self_cleanup(uninstall_root: str) -> None:
    try:
        fd, cmd_path = tempfile.mkstemp(prefix="m3dia-worker-uninstall-cleanup-", suffix=".cmd")
        os.close(fd)
        cp = Path(cmd_path)
        cp.write_text(
            "@echo off\r\n"
            "ping.exe 127.0.0.1 -n 3 >nul 2>&1\r\n"
            f'rd /s /q "{uninstall_root}" >nul 2>&1\r\n'
            'del /f /q "%~f0" >nul 2>&1\r\n',
            encoding="ascii", errors="ignore",
        )
        subprocess.Popen(
            ["cmd.exe", "/d", "/c", str(cp)],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            **hidden_kwargs(),
        )
    except Exception as exc:
        log(f"Auto-suppression du desinstalleur non programmee: {exc}.", 2)


def uninstall_worker(config: dict, wrapper_path: str | Path, elevated: bool = False) -> int:
    if not IS_WINDOWS:
        log("Desinstalleur Worker Windows appele hors Windows.", 2)
        return 0

    wrapper = Path(wrapper_path).resolve()
    if not is_admin() and not elevated:
        return elevate_and_wait(wrapper)

    log("Desinstallation Worker commencee. Absence=succes. Erreur elementaire=continue.")

    for name in config.get("tasks", []):
        try:
            remove_task(name)
        except Exception as exc:
            log(f"Tache ignoree apres erreur: {name}: {exc}.", 2)

    try:
        remove_logoff_handler(str(config.get("logoff_key") or ""))
    except Exception as exc:
        log(f"Handler logoff ignore apres erreur: {exc}.", 2)

    for path in config.get("defender_paths", []):
        try:
            remove_defender(path)
        except Exception as exc:
            log(f"Defender ignore apres erreur: {path}: {exc}.", 2)

    for path in config.get("registry_paths", []):
        try:
            remove_registry(path)
        except Exception as exc:
            log(f"Registre ignore apres erreur: {path}: {exc}.", 2)

    for path in config.get("install_dirs", []):
        try:
            remove_tree(path)
        except Exception as exc:
            log(f"Dossier installation ignore apres erreur: {path}: {exc}.", 2)

    log("Desinstallation Worker terminee.")
    schedule_self_cleanup(str(config["uninstall_root"]))
    return 0
