from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

from .platforms import hidden_process_kwargs

_TASK_COMMANDS = {
    "M3DIACompute Worker Monitor": "monitor",
    "M3DIACompute Worker WakePoll": "wake-poll",
    "M3DIACompute Worker Retry": "retry",
    "M3DIACompute Worker JobRunner": "job",
    "M3DIACompute Worker JobGuard": "guard",
}


def _pythonw() -> str:
    if os.name != "nt":
        return sys.executable
    p = Path(sys.executable)
    candidate = p if p.name.lower() == "pythonw.exe" else p.with_name("pythonw.exe")
    if not candidate.is_file():
        raise RuntimeError(f"pythonw.exe introuvable: {candidate}")
    return str(candidate)


def _worker_wrapper() -> str:
    cfg = os.getenv("M3DIA_WORKER_CONFIG", "")
    if cfg:
        p = Path(cfg)
        if p.parent.name.lower() == "state":
            return str(p.parent.parent / "worker_main.py")
    argv0 = Path(sys.argv[0]).resolve()
    if argv0.name == "worker_main.py":
        return str(argv0)
    return str(argv0.parent / "worker_main.py")


def run_task(name: str) -> None:
    if os.name == "nt":
        subprocess.run(
            ["schtasks.exe", "/Run", "/TN", str(name)],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            **hidden_process_kwargs(),
        )
        return
    # AdminExecutor is started by systemd.path / launchd QueueDirectories as root.
    if str(name) == "M3DIACompute Worker AdminExecutor":
        return
    command = _TASK_COMMANDS.get(str(name))
    if not command:
        return
    subprocess.Popen(
        [sys.executable, _worker_wrapper(), command],
        start_new_session=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=True,
    )


def defer_task(name: str, seconds: float) -> None:
    """Relance une action locale apres un court delai sans deranger l'utilisateur."""
    delay = max(0.0, float(seconds))
    if os.name == "nt":
        code = (
            "import subprocess,time;"
            f"time.sleep({delay!r});"
            "subprocess.run("
            f"{['schtasks.exe','/Run','/TN',str(name)]!r},"
            "stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,"
            "check=False,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0x08000000))"
        )
        subprocess.Popen(
            [_pythonw(), "-c", code],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            **hidden_process_kwargs(),
        )
        return

    command = _TASK_COMMANDS.get(str(name))
    if not command or str(name) == "M3DIACompute Worker AdminExecutor":
        return
    code = (
        "import subprocess,time;"
        f"time.sleep({delay!r});"
        f"subprocess.Popen({[sys.executable, _worker_wrapper(), command]!r},"
        "start_new_session=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,close_fds=True)"
    )
    subprocess.Popen(
        [sys.executable, "-c", code],
        start_new_session=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=True,
    )
