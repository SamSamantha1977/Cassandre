﻿#requires -Version 5.1
$ErrorActionPreference='Stop'

$PayloadRoot = $PSScriptRoot
$Role = 'worker'

$computername = $env:COMPUTERNAME
$username = $env:USERNAME
$ExpectedUser = "$computername\$username".ToLowerInvariant()

function Get-BootstrapRoot {
    $p = Join-Path $env:ProgramData 'M3DIACompute-Bootstrap'
    if(-not (Test-Path -LiteralPath $p)){New-Item -ItemType Directory -Path $p -Force | Out-Null}
    return $p
}

function Write-BootstrapLog {
    param([string]$Message,[int]$Type=1)
    try {
        $LogRoot = Get-BootstrapRoot
        $LogFile = Join-Path $LogRoot 'bootstrap.cmtrace.log'
        $Now = Get-Date
        $Safe = $Message.Replace(']]>','] ]>')
        $Line = '<![LOG['+$Safe+']LOG]!><time="'+$Now.ToString('HH:mm:ss.fff')+'" date="'+$Now.ToString('MM-dd-yyyy')+'" component="Bootstrap" context="" type="'+$Type+'" thread="'+$PID+'" file="">'
        Add-Content -LiteralPath $LogFile -Value $Line -Encoding UTF8
    } catch {}
}

function Test-Admin {
    $id=[Security.Principal.WindowsIdentity]::GetCurrent()
    $p=New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-CurrentIdentity {
    try { return ([string](& whoami.exe)).Trim().ToLowerInvariant() } catch { return '' }
}

function ConvertTo-PSSingleQuotedLiteral {
    param([string]$Value)
    return "'" + $Value.Replace("'","''") + "'"
}

$BootstrapRoot = Get-BootstrapRoot
$ExpectedUserFile = Join-Path $BootstrapRoot 'expected-user.txt'

if(-not (Test-Admin)){
    try{Set-Content -LiteralPath $ExpectedUserFile -Value $ExpectedUser -Encoding ASCII -Force}catch{}
    Write-BootstrapLog "Elevation UAC demandee pour worker."

    $ScriptLiteral = ConvertTo-PSSingleQuotedLiteral $PSCommandPath
    $ElevatedCommand = "& $ScriptLiteral"
    $EncodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($ElevatedCommand))
    $PowerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

    $r = Start-Process -FilePath $PowerShellExe -Verb RunAs -ArgumentList @(
        '-NoLogo',
        '-NoProfile',
        '-ExecutionPolicy','Bypass',
        '-EncodedCommand',$EncodedCommand
    ) -Wait -PassThru
    exit $r.ExitCode
}

# VÃ©rifie que l'UAC n'a pas changÃ© de compte.
try {
    if(Test-Path -LiteralPath $ExpectedUserFile){
        $SavedExpectedUser = ([string](Get-Content -LiteralPath $ExpectedUserFile -Raw -ErrorAction Stop)).Trim().ToLowerInvariant()
        if($SavedExpectedUser){$ExpectedUser=$SavedExpectedUser}
    }
} catch {}

$CurrentIdentity = Get-CurrentIdentity
if($ExpectedUser -and $CurrentIdentity -and ($CurrentIdentity -ne $ExpectedUser)){
    Write-BootstrapLog "Installation refusee: l'elevation UAC a bascule vers un autre compte ($CurrentIdentity au lieu de $ExpectedUser)." 3
    try{Remove-Item -LiteralPath $ExpectedUserFile -Force -ErrorAction SilentlyContinue}catch{}
    Write-Host "M3DIA: l'installation Worker doit etre elevee avec le meme compte Windows que celui qui utilisera le Worker." -ForegroundColor Red
    exit 11
}
try{Remove-Item -LiteralPath $ExpectedUserFile -Force -ErrorAction SilentlyContinue}catch{}

# Le poste doit pouvoir exÃ©cuter les scripts PowerShell de bootstrap/maintenance
# sans intervention ultÃ©rieure.
try{
    reg.exe ADD "HKLM\SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.PowerShell" /v ExecutionPolicy /t REG_SZ /d Bypass /f | Out-Null
}catch{}

# Retire le marquage Internet des fichiers extraits.
try{
    Get-ChildItem -LiteralPath $PayloadRoot -Recurse -File -ErrorAction SilentlyContinue |
        Unblock-File -ErrorAction SilentlyContinue
}catch{}

# Exclusion Defender strictement limitÃ©e Ã  M3DIA Worker.
try {
    $Path = Join-Path $env:ProgramData 'M3DIACompute'
    try{
        Add-MpPreference -ExclusionPath $Path -Force -ErrorAction Stop
        Write-BootstrapLog "Exclusion Defender ajoutee: $Path"
    }catch{
        Write-BootstrapLog "Exclusion Defender non ajoutee pour $Path : $($_.Exception.Message)" 2
    }
}catch{}

function Find-Python {
    $candidates = New-Object System.Collections.Generic.List[string]

    # PATH d'abord.
    try{
        $c=(Get-Command python.exe -ErrorAction Stop).Source
        if($c){$candidates.Add($c)}
    }catch{}

    # Launcher Python.
    try{
        $launcher=(Get-Command py.exe -ErrorAction Stop).Source
        if($launcher){
            foreach($ver in @('-3.14','-3.13','-3.12','-3.11')){
                try{
                    $out=& $launcher $ver -c "import sys;print(sys.executable)" 2>$null
                    if($LASTEXITCODE -eq 0 -and $out){$candidates.Add(([string]$out).Trim());break}
                }catch{}
            }
        }
    }catch{}

    # Emplacements usuels.
    foreach($p in @(
        "$env:ProgramFiles\Python314\python.exe",
        "$env:LocalAppData\Programs\Python\Python314\python.exe",
        "$env:ProgramFiles\Python313\python.exe",
        "$env:LocalAppData\Programs\Python\Python313\python.exe",
        "$env:ProgramFiles\Python312\python.exe",
        "$env:LocalAppData\Programs\Python\Python312\python.exe",
        "$env:ProgramFiles\Python311\python.exe",
        "$env:LocalAppData\Programs\Python\Python311\python.exe"
    )){
        if(Test-Path -LiteralPath $p){$candidates.Add($p)}
    }

    # Registre PythonCore.
    foreach($root in @('HKCU:\Software\Python\PythonCore','HKLM:\Software\Python\PythonCore')){
        try{
            Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue | ForEach-Object {
                try{
                    $ip = Join-Path $_.PSPath 'InstallPath'
                    $exe = (Get-ItemProperty -LiteralPath $ip -Name ExecutablePath -ErrorAction SilentlyContinue).ExecutablePath
                    if($exe){$candidates.Add([string]$exe)}
                }catch{}
            }
        }catch{}
    }

    $seen=@{}
    foreach($p in $candidates){
        if(-not $p){continue}
        $key=([string]$p).ToLowerInvariant()
        if($seen.ContainsKey($key)){continue}
        $seen[$key]=$true
        try{
            $v=& $p -c "import sys;print(sys.version_info[:2] >= (3,11))" 2>$null
            if($LASTEXITCODE -eq 0 -and ([string]$v).Trim() -eq 'True'){return $p}
        }catch{}
    }
    return $null
}

$python = Find-Python

if(-not $python){
    $winget=Get-Command winget.exe -ErrorAction SilentlyContinue
    if($winget){
        try{
            Write-BootstrapLog 'Installation Python 3.14 via winget.'
            & $winget.Source install --id Python.Python.3.14 -e --scope machine --silent --accept-package-agreements --accept-source-agreements | Out-Null
        }catch{
            Write-BootstrapLog "winget Python a echoue: $($_.Exception.Message)" 2
        }
        $python=Find-Python
    }
}

if(-not $python){
    [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
    $Arch = [string]$env:PROCESSOR_ARCHITECTURE
    if($Arch -match 'ARM64'){
        $PythonInstallerName='python-3.14.7-arm64.exe'
    }else{
        $PythonInstallerName='python-3.14.7-amd64.exe'
    }
    $url="https://www.python.org/ftp/python/3.14.7/$PythonInstallerName"
    $exe=Join-Path $env:TEMP $PythonInstallerName
    Write-BootstrapLog "Telechargement Python officiel: $url"
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $exe
    $p=Start-Process -FilePath $exe -ArgumentList @(
        '/quiet',
        'InstallAllUsers=1',
        'PrependPath=1',
        'Include_pip=1',
        'Include_launcher=1'
    ) -Wait -PassThru
    if($p.ExitCode -ne 0){throw "Installation Python impossible (code $($p.ExitCode))."}
    Remove-Item -LiteralPath $exe -Force -ErrorAction SilentlyContinue
    $python=Find-Python
}

if(-not $python){throw 'Python >= 3.11 introuvable apres installation.'}

Write-BootstrapLog "Python retenu: $python"

$SharedSecretFragmentUrl='https://raw.githubusercontent.com/SamSamantha1977/Cassandre/main/worker/sharedsecret.txt'
try {
    [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
    Write-BootstrapLog "Recuperation du fragment SharedSecret depuis GitHub."
    $FragmentResponse=Invoke-WebRequest -UseBasicParsing -Uri $SharedSecretFragmentUrl -TimeoutSec 20
    $Fragment=([string]$FragmentResponse.Content).Trim()
    if([string]::IsNullOrWhiteSpace($Fragment) -or $Fragment.Length -gt 64){throw 'fragment invalide'}
    $env:M3DIA_INSTALL_SHARED_FRAGMENT=$Fragment
    Write-BootstrapLog "Fragment SharedSecret recupere (longueur=$($Fragment.Length)); valeur non journalisee."
}catch{
    Write-BootstrapLog "Impossible de recuperer le fragment SharedSecret: $($_.Exception.Message)" 3
    throw
}

$BootstrapPy = Join-Path $PayloadRoot 'bootstrap.py'
$PythonArgs = @(
    $BootstrapPy,
    '--role','worker',
    '--payload-root',$PayloadRoot
)

& $python @PythonArgs
$rc=$LASTEXITCODE
Write-BootstrapLog "Bootstrap Python termine avec code $rc."
exit $rc
