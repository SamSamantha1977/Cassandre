from __future__ import annotations

import argparse
import contextlib
import csv
import hashlib
import html
import http.client
import io
import json
import os
import shutil
import ssl
import subprocess
import sys
import tempfile
import textwrap
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from pathlib import Path

from .common import cmtrace, ensure_dir, iso_now, json_read
from .config import bootstrap_worker_state, default_worker, worker_store
from .platforms import is_portable, hidden_process_kwargs
from .platform_integration import install_linux_units, install_macos_plists
from .uninstall_install import install_worker_uninstaller
from .worker_config import WORKER_CONFIG_REQUIRED

IS_WINDOWS = os.name == "nt"
IS_MACOS = sys.platform == "darwin"
IS_LINUX = (not IS_WINDOWS and not IS_MACOS)
TASK_NS = "http://schemas.microsoft.com/windows/2004/02/mit/task"
VALID_LOGON_TYPES = {"S4U", "Password", "InteractiveToken", "InteractiveTokenOrPassword"}
VALID_RUN_LEVELS = {"LeastPrivilege", "HighestAvailable"}


def _qxml(value: object) -> str:
    return html.escape(str(value), quote=True)


def _win_identity() -> tuple[str, str]:
    """Return DOMAIN\\user and SID for the account running the installer."""
    user = subprocess.check_output(["whoami.exe"], text=True, errors="replace", **hidden_process_kwargs()).strip()
    sid = ""
    try:
        out = subprocess.check_output(
            ["whoami.exe", "/user", "/fo", "csv", "/nh"],
            text=True,
            errors="replace",
            **hidden_process_kwargs(),
        ).strip()
        rows = list(csv.reader(io.StringIO(out)))
        if rows and len(rows[0]) >= 2:
            sid = rows[0][1].strip()
    except Exception:
        pass
    return user, sid


def _task_xml(
    command: str,
    args: list[str],
    principal: str,
    logon_type: str | None,
    run_level: str,
    triggers: str = "",
    wake: bool = False,
    execution_limit: str = "PT5M",
    restart_interval: str | None = None,
    restart_count: int = 0,
) -> str:
    """Build Task Scheduler XML using only values accepted by the XML schema.

    Important: TASK_LOGON_SERVICE_ACCOUNT/"ServiceAccount" is a COM API enum,
    NOT a legal value of the Task Scheduler XML <LogonType> element. For
    LOCAL SYSTEM tasks the XML intentionally omits <LogonType>; UserId
    S-1-5-18 is sufficient and is explicitly accepted by the schema/protocol.
    """
    if logon_type is not None and logon_type not in VALID_LOGON_TYPES:
        raise ValueError(f"Unsupported Task Scheduler XML LogonType: {logon_type}")
    if run_level not in VALID_RUN_LEVELS:
        raise ValueError(f"Unsupported Task Scheduler XML RunLevel: {run_level}")
    if not principal:
        raise ValueError("Task Scheduler principal must not be empty")

    argstr = subprocess.list2cmdline([str(x) for x in args])
    logon_xml = f"<LogonType>{_qxml(logon_type)}</LogonType>" if logon_type else ""
    restart_xml = ""
    if restart_interval and int(restart_count) > 0:
        if not 1 <= int(restart_count) <= 255:
            raise ValueError("Task Scheduler RestartOnFailure Count must be between 1 and 255")
        restart_xml = (
            "<RestartOnFailure>"
            f"<Interval>{_qxml(restart_interval)}</Interval>"
            f"<Count>{int(restart_count)}</Count>"
            "</RestartOnFailure>"
        )

    xml = f'''<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="{TASK_NS}">
  <RegistrationInfo><Description>M3DIA Compute</Description></RegistrationInfo>
  <Triggers>{triggers}</Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>{_qxml(principal)}</UserId>
      {logon_xml}
      <RunLevel>{_qxml(run_level)}</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings><StopOnIdleEnd>false</StopOnIdleEnd><RestartOnIdle>false</RestartOnIdle></IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>true</Hidden>
    <WakeToRun>{str(wake).lower()}</WakeToRun>
    <ExecutionTimeLimit>{_qxml(execution_limit)}</ExecutionTimeLimit>
    <Priority>7</Priority>
    {restart_xml}
  </Settings>
  <Actions Context="Author">
    <Exec><Command>{_qxml(command)}</Command><Arguments>{_qxml(argstr)}</Arguments></Exec>
  </Actions>
</Task>'''
    _validate_task_xml(xml)
    return xml


def _validate_task_xml(xml: str) -> None:
    """Fail locally before schtasks.exe if we generate an invalid principal."""
    root = ET.fromstring(xml)
    ns = {"t": TASK_NS}
    logon = root.find(".//t:Principal/t:LogonType", ns)
    if logon is not None and (logon.text or "") not in VALID_LOGON_TYPES:
        raise ValueError(f"Invalid Task Scheduler XML LogonType: {logon.text!r}")
    runlevel = root.find(".//t:Principal/t:RunLevel", ns)
    if runlevel is None or (runlevel.text or "") not in VALID_RUN_LEVELS:
        raise ValueError(f"Invalid Task Scheduler XML RunLevel: {None if runlevel is None else runlevel.text!r}")
    userid = root.find(".//t:Principal/t:UserId", ns)
    if userid is None or not (userid.text or "").strip():
        raise ValueError("Task Scheduler XML has no UserId")


def _safe_file_component(name: str) -> str:
    return "".join(ch if ch.isalnum() or ch in ("-", "_", ".") else "_" for ch in name)[:120]


def _create_task(
    name: str,
    command: str,
    args: list[str],
    principal: str,
    logon_type: str | None,
    run_level: str,
    triggers: str = "",
    wake: bool = False,
    execution_limit: str = "PT5M",
    *,
    log_path: str | Path | None = None,
    restart_interval: str | None = None,
    restart_count: int = 0,
) -> None:
    xml = _task_xml(
        command,
        args,
        principal,
        logon_type,
        run_level,
        triggers,
        wake,
        execution_limit,
        restart_interval,
        restart_count,
    )
    fd, tmp = tempfile.mkstemp(prefix="m3dia-task-", suffix=".xml")
    os.close(fd)
    Path(tmp).write_text(xml, encoding="utf-16")
    try:
        # If an older copy is running, terminate the task instance before
        # replacing the definition. /End on a missing/not-running task is
        # harmless and intentionally ignored.
        subprocess.run(
            ["schtasks.exe", "/End", "/TN", name],
            capture_output=True,
            text=True,
            errors="replace",
            check=False,
            **hidden_process_kwargs(),
        )
        result = subprocess.run(
            ["schtasks.exe", "/Create", "/TN", name, "/XML", tmp, "/F"],
            capture_output=True,
            text=True,
            errors="replace",
            check=False,
            **hidden_process_kwargs(),
        )
        if result.returncode != 0:
            detail = (
                f"schtasks.exe /Create a echoue pour '{name}' (code {result.returncode}). "
                f"stdout={result.stdout.strip()!r} stderr={result.stderr.strip()!r}"
            )
            if log_path:
                log_path = Path(log_path)
                debug = ensure_dir(log_path.parent / "TaskSchedulerErrors")
                stem = f"{datetime.now():%Y%m%d-%H%M%S}-{_safe_file_component(name)}"
                xml_copy = debug / f"{stem}.xml"
                txt_copy = debug / f"{stem}.txt"
                xml_copy.write_text(xml, encoding="utf-16")
                txt_copy.write_text(detail + "\n", encoding="utf-8")
                cmtrace(log_path, detail, "Installer", 3)
                cmtrace(log_path, f"XML Task Scheduler conserve: {xml_copy}", "Installer", 3)
            raise RuntimeError(detail)
        if log_path:
            cmtrace(Path(log_path), f"Tache planifiee creee/remplacee: {name}", "Installer")
    finally:
        Path(tmp).unlink(missing_ok=True)


def _time_trigger(dt: datetime, repetition_minutes: int | None = None) -> str:
    boundary = dt.astimezone().replace(microsecond=0).isoformat()
    rep = (
        f"<Repetition><Interval>PT{int(repetition_minutes)}M</Interval>"
        "<Duration>P3650D</Duration><StopAtDurationEnd>false</StopAtDurationEnd></Repetition>"
        if repetition_minutes
        else ""
    )
    return f"<TimeTrigger><StartBoundary>{_qxml(boundary)}</StartBoundary><Enabled>true</Enabled>{rep}</TimeTrigger>"


def _logon_trigger(user: str) -> str:
    return f"<LogonTrigger><Enabled>true</Enabled><UserId>{_qxml(user)}</UserId></LogonTrigger>"


def _boot_trigger() -> str:
    return "<BootTrigger><Enabled>true</Enabled></BootTrigger>"


def windows_schedule_once(name: str, argv: list[str], when: datetime, run_as_system: bool = False, wake: bool = False, log_path: str | Path | None = None) -> None:
    user, _sid = _win_identity()
    principal = "S-1-5-18" if run_as_system else user
    # XML schema has no "ServiceAccount" value. Omit LogonType for SYSTEM.
    logon = None if run_as_system else "InteractiveToken"
    level = "HighestAvailable" if run_as_system else "LeastPrivilege"
    _create_task(
        name,
        argv[0],
        argv[1:],
        principal,
        logon,
        level,
        _time_trigger(when),
        wake,
        "PT5M",
        log_path=log_path,
    )


def _pythonw() -> str:
    if not IS_WINDOWS:
        return sys.executable
    p = Path(sys.executable)
    w = p.with_name("pythonw.exe")
    if not w.is_file():
        raise RuntimeError(
            f"pythonw.exe est obligatoire pour les taches M3DIA sans fenetre, mais il est introuvable: {w}"
        )
    return str(w)


def _copy_app(payload_root: Path, install_root: Path) -> Path:
    app = install_root / "app"
    shutil.rmtree(app, ignore_errors=True)
    ensure_dir(app)
    shutil.copytree(payload_root / "m3dia", app / "m3dia", dirs_exist_ok=True)
    for f in ("requirements.txt",):
        shutil.copy2(payload_root / f, app / f)
    return app


def _wrapper(path: Path, module: str) -> None:
    path.write_text(
        "import sys\n"
        "from pathlib import Path\n"
        "sys.path.insert(0,str(Path(__file__).resolve().parent/'app'))\n"
        f"from {module} import main\n"
        "main()\n",
        encoding="utf-8",
    )


def _set_execution_policy_bypass() -> None:
    if not IS_WINDOWS:
        return
    import winreg

    p = r"SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.PowerShell"
    with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, p, 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, "ExecutionPolicy", 0, winreg.REG_SZ, "Bypass")


def _grant_modify(path: Path, user: str, log_path: str | Path | None = None) -> None:
    if not IS_WINDOWS:
        return
    result = subprocess.run(
        ["icacls.exe", str(path), "/grant", f"{user}:(OI)(CI)M", "/T", "/C"],
        capture_output=True,
        text=True,
        errors="replace",
        check=False,
        **hidden_process_kwargs(),
    )
    if result.returncode not in (0,):
        msg = f"icacls a retourne {result.returncode} pour {path}: {result.stderr.strip() or result.stdout.strip()}"
        if log_path:
            cmtrace(Path(log_path), msg, "Installer", 2)


def _run_logged(command: list[str], log_path: Path, description: str, *, check: bool = False) -> subprocess.CompletedProcess:
    result = subprocess.run(command, capture_output=True, text=True, errors="replace", check=False, **hidden_process_kwargs())
    output = " | ".join(x for x in (result.stdout.strip(), result.stderr.strip()) if x)
    cmtrace(log_path, f"{description}: code={result.returncode}" + (f" output={output}" if output else ""), "Installer", 1 if result.returncode == 0 else 2)
    if check and result.returncode != 0:
        raise RuntimeError(f"{description} a echoue (code {result.returncode}): {output}")
    return result


def _controller_health_check(port: int, cert_path: Path, log_path: Path, timeout_seconds: float = 15.0) -> None:
    """Verify that the just-created SYSTEM task really starts the Python controller."""
    # Pin the certificate by SHA-256 so the self-test also verifies that the
    # process listening on the port is the M3DIA controller we just installed.
    pem = cert_path.read_text(encoding="utf-8")
    expected = hashlib.sha256(ssl.PEM_cert_to_DER_cert(pem)).hexdigest().upper()
    deadline = time.monotonic() + timeout_seconds
    last_error = ""
    while time.monotonic() < deadline:
        conn = None
        try:
            context = ssl._create_unverified_context()
            conn = http.client.HTTPSConnection("127.0.0.1", int(port), timeout=2.0, context=context)
            conn.connect()
            cert = conn.sock.getpeercert(binary_form=True) if conn.sock else None
            actual = hashlib.sha256(cert or b"").hexdigest().upper()
            if not cert or actual != expected:
                raise RuntimeError(f"certificat TLS inattendu sur 127.0.0.1:{port}: {actual}")
            conn.request("GET", "/api/health", headers={"Connection": "close"})
            response = conn.getresponse()
            raw = response.read()
            data = json.loads(raw.decode("utf-8")) if raw else {}
            if response.status == 200 and isinstance(data, dict) and data.get("Status") == "OK":
                cmtrace(log_path, f"Auto-test Controller HTTPS OK sur 127.0.0.1:{port}.", "Installer")
                return
            last_error = f"HTTP {response.status}: {raw[:500]!r}"
        except Exception as exc:
            last_error = str(exc)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
        time.sleep(0.5)
    raise RuntimeError(f"Le Controller HTTPS n'a pas passe l'auto-test local apres {timeout_seconds:.0f}s: {last_error}")


def _worker_initial_configuration_check(root: Path, app: Path, log_path: Path, attempts: int = 3) -> None:
    """Require a complete Controller-provided configuration before reporting success."""
    env = os.environ.copy()
    env["PYTHONPATH"] = str(app)
    if not IS_WINDOWS:
        env["M3DIA_WORKER_CONFIG"] = str(root / "State" / "worker.json")
    last_error = ""
    for attempt in range(1, max(1, attempts) + 1):
        try:
            result = subprocess.run(
                [sys.executable, str(root / "worker_main.py"), "network"],
                timeout=20,
                env=env,
                capture_output=True,
                text=True,
                errors="replace",
                check=False,
                **hidden_process_kwargs(),
            )
            output = " | ".join(x for x in (result.stdout.strip(), result.stderr.strip()) if x)
            if result.returncode != 0:
                last_error = f"code={result.returncode}" + (f" output={output}" if output else "")
            else:
                document = json_read(root / "Config" / "worker-config.json", {}) or {}
                if isinstance(document, dict) and WORKER_CONFIG_REQUIRED.issubset(document):
                    cmtrace(log_path, "Configuration initiale WORKER recue et validee.", "Installer")
                    return
                last_error = "worker-config.json absent ou incomplet apres le cycle reseau"
        except subprocess.TimeoutExpired:
            last_error = "cycle reseau expire apres 20 secondes"
        cmtrace(
            log_path,
            f"Configuration initiale WORKER non recue, tentative {attempt}/{max(1, attempts)}: {last_error}",
            "Installer",
            2,
        )
        if attempt < max(1, attempts):
            time.sleep(2.0)
    raise RuntimeError(f"Configuration initiale WORKER indisponible: {last_error}")


def install_worker(payload_root: Path, controller_url: str | None = None, rendezvous_url: str | None = None):
    if IS_WINDOWS:
        root = Path(os.getenv("PROGRAMDATA", r"C:\ProgramData")) / "M3DIACompute"
    elif IS_MACOS:
        root = Path("/Library/Application Support/M3DIACompute")
    else:
        root = Path("/opt/m3diacompute")
    if not IS_WINDOWS and (not hasattr(os,"geteuid") or os.geteuid()!=0):
        raise PermissionError("L'installation M3DIA Worker Linux/macOS doit etre lancee avec les droits administrateur une seule fois.")
    for d in (root, root / "Logs", root / "Inbox", root / "Outbox", root / "State", root / "Config", root / "AdminQueue", root / "AdminDone", root / "AdminFailed", root / "Updates"):
        ensure_dir(d)
    log = root / "Logs" / "install.cmtrace.log"
    cmtrace(log, "Installation Worker Python multi-OS commencee.", "Installer")
    app = _copy_app(payload_root, root)
    _wrapper(root / "worker_main.py", "m3dia.worker")
    suffix_source=payload_root / "config.ini"
    if not suffix_source.is_file():raise FileNotFoundError(f"config.ini absent du package: {suffix_source}")
    suffix_target=root / "Config" / "config.ini"
    shutil.copy2(suffix_source,suffix_target)
    fragment=str(os.getenv("M3DIA_INSTALL_SHARED_FRAGMENT","") or "").strip()
    if not fragment:raise RuntimeError("Fragment SharedSecret d'installation non recupere depuis GitHub")
    defaults = default_worker(str(root))
    if IS_WINDOWS:
        store = worker_store(None, defaults)
    else:
        store = worker_store(root / "State" / "worker.json", defaults)
    old = store.load(); new = bootstrap_worker_state(old, defaults)
    new.update({"version":"5.1.0","install_root":str(root),"is_portable":is_portable(),"install_shared_secret":"","install_shared_fragment":fragment,"install_secret_suffix_file":str(suffix_target)})
    if controller_url:new["controller_url"] = controller_url
    store.save(new)
    if IS_WINDOWS:
        user, _sid = _win_identity()
        install_worker_uninstaller(root, user, _sid, log)
        _set_execution_policy_bypass(); _grant_modify(root, user, log)
        py = _pythonw(); wrapper = str(root / "worker_main.py")
        subprocess.run(["powercfg.exe", "/setacvalueindex", "SCHEME_CURRENT", "SUB_SLEEP", "RTCWAKE", "1"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **hidden_process_kwargs())
        if not new["is_portable"]:
            subprocess.run(["powercfg.exe", "/change", "hibernate-timeout-ac", "0"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **hidden_process_kwargs())
        _create_task("M3DIACompute Worker Monitor", py, [wrapper, "monitor"], user, "InteractiveToken", "LeastPrivilege", _logon_trigger(user), False, "PT5M", log_path=log)
        _create_task("M3DIACompute Worker WakePoll", py, [wrapper, "wake-poll"], user, "InteractiveToken", "LeastPrivilege", _time_trigger(datetime.now().astimezone() + timedelta(minutes=1), 5), not new["is_portable"], "PT5M", log_path=log)
        windows_schedule_once("M3DIACompute Worker Retry", [py, wrapper, "retry"], datetime.now().astimezone() + timedelta(days=3650), False, not new["is_portable"], log)
        _create_task("M3DIACompute Worker JobRunner", py, [wrapper, "job"], user, "InteractiveToken", "LeastPrivilege", "", False, "PT0S", log_path=log)
        _create_task("M3DIACompute Worker JobGuard", py, [wrapper, "guard"], user, "InteractiveToken", "LeastPrivilege", "", False, "PT5M", log_path=log)
        # Le privilege est consomme une seule fois a l'installation. Ensuite
        # le Worker utilise cette tache SYSTEM sans nouvelle UAC.
        _create_task("M3DIACompute Worker AdminExecutor", py, [wrapper, "admin-executor"], "S-1-5-18", None, "HighestAvailable", "", False, "PT0S", log_path=log)
        try:
            import winreg
            kpath = r"Software\Microsoft\Windows\CurrentVersion\Group Policy\Scripts\Logoff\0\0"
            with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, kpath, 0, winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, "Script", 0, winreg.REG_SZ, py)
                winreg.SetValueEx(k, "Parameters", 0, winreg.REG_SZ, subprocess.list2cmdline([wrapper, "session-end", "--reason", "LOGOFF"]))
                winreg.SetValueEx(k, "IsPowershell", 0, winreg.REG_DWORD, 0)
        except Exception as exc:cmtrace(log, f"Logoff handler non inscrit: {exc}", "Installer", 2)
        subprocess.run(["schtasks.exe", "/Run", "/TN", "M3DIACompute Worker Monitor"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **hidden_process_kwargs())
    else:
        owner=str(os.getenv("SUDO_USER") or os.getenv("M3DIA_INSTALL_USER") or os.getenv("USER") or "root")
        try:
            import pwd
            account=pwd.getpwnam(owner); uid=account.pw_uid; gid=account.pw_gid
            for writable in (root/"Logs",root/"Inbox",root/"Outbox",root/"State",root/"Config",root/"AdminQueue",root/"AdminDone",root/"AdminFailed",root/"Updates"):
                for current,dirs,files in os.walk(writable):
                    os.chown(current,uid,gid)
                    for name in dirs:
                        with contextlib.suppress(Exception):os.chown(Path(current)/name,uid,gid)
                    for name in files:
                        with contextlib.suppress(Exception):os.chown(Path(current)/name,uid,gid)
        except Exception as exc:cmtrace(log,f"Ajustement proprietaire incomplet: {exc}","Installer",2)
        if IS_MACOS:
            install_macos_plists(root,sys.executable,owner)
            subprocess.run(["xattr","-dr","com.apple.quarantine",str(root)],check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        else:
            install_linux_units(root,sys.executable,owner)
    _worker_initial_configuration_check(root, app, log)
    if IS_WINDOWS:
        user, _sid = _win_identity(); install_worker_uninstaller(root, user, _sid, log)
    cmtrace(log, "Installation Worker Python multi-OS terminee.", "Installer")
    config_location="HKCU\\Software\\M3DIA\\Compute\\Worker" if IS_WINDOWS else str(root / "State" / "worker.json")
    return {"Status":"OK","Role":"WORKER","Version":"5.1.0","InstallRoot":str(root),"Config":config_location}


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument("--payload-root",default=str(Path(__file__).resolve().parents[1]))
    p.add_argument("--controller-url")
    p.add_argument("--rendezvous-url")
    a=p.parse_args(argv)
    print(json.dumps(install_worker(Path(a.payload_root),a.controller_url,a.rendezvous_url),indent=2))

if __name__=="__main__":main()
