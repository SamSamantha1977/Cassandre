# Cassandra — M3DIACompute Worker

Cassandra permet à un ordinateur de mettre automatiquement à disposition une partie de ses ressources inutilisées pour participer à une puissance de calcul distribuée.

Le **WORKER** est volontairement une coquille légère : l'installation met en place le runtime, les mécanismes locaux nécessaires et la communication avec le CONTROLLER. La configuration opérationnelle, les affectations et l'intelligence d'orchestration restent pilotées par le CONTROLLER.

L'objectif est que Cassandra fonctionne en arrière-plan **sans déranger l'utilisateur** : lorsqu'il utilise son ordinateur, le WORKER doit céder la place ; lorsqu'une opération locale exige des privilèges élevés, le WORKER utilise le mécanisme privilégié installé une seule fois pendant l'installation au lieu de redemander régulièrement un mot de passe.

## Télécharger

Les packages sont publiés dans la Release GitHub `worker-bootstrap` :

- **Windows** : `M3DIA-Worker-Windows.zip`
- **Linux** : `M3DIA-Worker-Linux.tar.gz`
- **macOS** : `M3DIA-Worker-macOS.zip` — support expérimental
- **Windows historique** : `M3DIA-Worker-setup.exe` — installateur 5.1 stable conservé tel quel

Les empreintes SHA-256 sont fournies dans `SHA256SUMS.txt`.

## Pourquoi Windows ou macOS peut-il afficher un avertissement ?

Cassandra est distribué gratuitement. Les fichiers ne sont actuellement pas signés à l'aide d'un **certificat commercial Windows ni d'un certificat Apple Developer ID qui sont payants (ce qui est contradictoire avec le principe de gratuité de Cassandra)**.

Cela peut entraîner un avertissement de Windows SmartScreen ou de macOS Gatekeeper. Un avertissement de provenance/signature n'est pas, à lui seul, une détection de malware. Les procédures ci-dessous indiquent exactement quoi faire : l'utilisateur n'a pas à rechercher une procédure dans une documentation externe.

## Windows

1. Téléchargez `M3DIA-Worker-Windows.zip` depuis la Release GitHub.
2. Extrayez entièrement l'archive.
3. Faites **clic droit** sur `lanceur.cmd` puis **Exécuter en tant qu'administrateur**.
4. Si Windows affiche un écran SmartScreen :
   - cliquez sur **Informations complémentaires** ;
   - cliquez sur **Exécuter quand même**.
5. Acceptez la demande UAC d'installation.
6. Cassandra installe ensuite son mécanisme `AdminExecutor` sous `SYSTEM`. Le fonctionnement normal ne doit donc pas redemander l'élévation à chaque tâche privilégiée.

Le bootstrap ajoute une exclusion Microsoft Defender limitée au répertoire du WORKER (`C:\ProgramData\M3DIACompute`) afin d'éviter qu'un traitement temporaire de Cassandra ne soit inutilement ralenti ou bloqué. Il ne désactive pas Defender.

## Linux

1. Téléchargez `M3DIA-Worker-Linux.tar.gz` depuis la Release GitHub.
2. Extrayez l'archive.
3. Ouvrez un terminal dans le dossier extrait.
4. Exécutez :

```sh
chmod +x install.sh
sudo ./install.sh
```

Le mot de passe administrateur est demandé pendant l'installation afin de créer les services `systemd`, dont l'`AdminExecutor` exécuté en `root`. Les opérations privilégiées ultérieures passent ensuite par ce mécanisme local sans nouvelle demande `sudo`.

Le bootstrap ne désactive ni SELinux ni AppArmor. Cassandra utilise les mécanismes système standards et ne nécessite normalement aucune ouverture de port entrant pour son contact avec le CONTROLLER. Les éventuels refus de politiques de sécurité locales sont journalisés.

## macOS — expérimental / fonctionnement non garanti

Cassandra utilise des processus automatiques en arrière-plan pour mesurer la disponibilité de la machine, contacter le CONTROLLER, démarrer, arrêter et reprendre des traitements sans déranger l'utilisateur. macOS applique des restrictions particulières aux tâches persistantes, aux LaunchDaemons et aux autorisations en arrière-plan. **Nous ne pouvons donc pas garantir que l'environnement nécessaire à Cassandra fonctionnera intégralement sur toutes les versions et configurations de macOS.**

La version macOS est testée en best effort et reste expérimentale.

Installation :

1. Téléchargez `M3DIA-Worker-macOS.zip` depuis la Release GitHub.
2. Extrayez l'archive.
3. Double-cliquez sur `install.command`.
4. Si macOS refuse l'ouverture parce que le développeur ne peut pas être vérifié :
   - ouvrez **Réglages Système** ;
   - ouvrez **Confidentialité et sécurité** ;
   - descendez jusqu'à la section **Sécurité** ;
   - cliquez sur **Ouvrir quand même** pour `install.command` ;
   - confirmez **Ouvrir**.
5. Saisissez le mot de passe administrateur lorsque l'installation le demande.
6. Si macOS demande d'autoriser Cassandra à fonctionner en arrière-plan, choisissez **Autoriser**.
7. Si nécessaire, ouvrez **Réglages Système → Général → Ouverture et extensions** et vérifiez que l'activité en arrière-plan de Cassandra est autorisée.

L'installation crée un LaunchDaemon `AdminExecutor` exécuté en `root`, de façon à ne pas demander le mot de passe à chaque opération privilégiée. Le bootstrap ne désactive ni Gatekeeper, ni XProtect, ni SIP. Il retire uniquement l'attribut de quarantaine de la copie Cassandra que l'utilisateur vient explicitement d'autoriser et d'installer.

## SharedSecret d'installation

L'installation utilise une `SharedSecret` d'installation pour le premier enrôlement du WORKER. Elle est reconstituée temporairement en mémoire à partir des éléments prévus par le bootstrap, puis utilisée dans un challenge **HMAC-SHA256**. La valeur reconstituée n'est ni enregistrée complète sur disque ni envoyée complète au CONTROLLER.

Après l'enrôlement, le CONTROLLER fournit une `SharedSecret` individuelle au WORKER pour son fonctionnement courant.

## Journaux

Les scripts et composants Cassandra produisent des journaux au format compatible **CMTrace**.

Emplacements principaux :

- Windows : `C:\ProgramData\M3DIACompute-Bootstrap\bootstrap.cmtrace.log` et `C:\ProgramData\M3DIACompute\Logs\`
- Linux : `/var/log/m3dia-compute-bootstrap.cmtrace.log` et `/opt/m3diacompute/Logs/`
- macOS : `/var/log/m3dia-compute-bootstrap.cmtrace.log` et `/Library/Application Support/M3DIACompute/Logs/`

## Désinstallation

Windows conserve le mécanisme de désinstallation déjà prévu par le WORKER 5.1. Les packages Linux/macOS installent leurs composants dans les emplacements système M3DIA dédiés ; les scripts de désinstallation multi-OS seront maintenus avec les mêmes règles de suppression propre et de journalisation CMTrace.

## Licence

Voir [LICENSE](LICENSE).
