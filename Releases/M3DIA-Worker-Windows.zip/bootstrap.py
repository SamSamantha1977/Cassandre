from __future__ import annotations
import subprocess,sys
from pathlib import Path

def main():
    root=Path(__file__).resolve().parent
    sys.path.insert(0,str(root))
    try:subprocess.run([sys.executable,"-m","ensurepip","--upgrade"],check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except Exception:pass
    req=root/"requirements.txt"
    if req.exists():subprocess.run([sys.executable,"-m","pip","install","--disable-pip-version-check","-r",str(req)],check=True)
    from m3dia.installer import install_worker
    install_worker(root)

if __name__=="__main__":main()
